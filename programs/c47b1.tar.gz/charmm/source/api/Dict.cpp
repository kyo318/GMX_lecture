// Copyright 2020 Josh Buckner
#include <algorithm>
#include <utility>
#include "Dict.h"

namespace fict {

  /// if key maps to a bool value return true, otherwise false
  /// \param key look for key->bool
  /// \return true if key->bool, false otherwise
  bool Dict::isBoolIn(std::string key) {
    std::map<std::string, bool>::iterator it;
    it = this->bools.find(key);
    bool found = false;
    if (it != this->bools.end()) {
      found = true;
    }
    return found;
  }

  /// if key maps to a double value return true, otherwise false
  /// \param key look for key->double
  /// \return true if key->double, false otherwise
  bool  Dict::isDoubleIn(std::string key) {
    std::map<std::string, double>::iterator it;
    it = this->doubles.find(key);
    bool found = false;
    if (it != this->doubles.end()) {
      found = true;
    }
    return found;
  }

  /// if key maps to a int value return true, otherwise false
  /// \param key look for key->int
  /// \return true if key->int, false otherwise
  bool  Dict::isIntIn(std::string key) {
    std::map<std::string, int>::iterator it;
    it = this->ints.find(key);
    bool found = false;
    if (it != this->ints.end()) {
      found = true;
    }
    return found;
  }

  /// if key maps to a string value return true, otherwise false
  /// \param key look for key->string
  /// \return true if key->string, false otherwise
  bool  Dict::isStringIn(std::string key) {
    std::map<std::string, std::string>::iterator it;
    it = this->strings.find(key);
    bool found = false;
    if (it != this->strings.end()) {
      found = true;
    }
    return found;
  }

  /// if key maps to something in the dict, return true, false otherwise
  /// \param key look for in dict
  /// \return true if key in dict, false otherwise
  bool  Dict::isIn(std::string key) {
    bool found = isBoolIn(key)
      || isDoubleIn(key)
      || isIntIn(key)
      || isStringIn(key);
    return found;
  }

  /// if key is in dict, remove key->value pair, and return true
  /// \param key look for this in dict
  /// \return true if key found and removed, false otherwise
  bool  Dict::remove(std::string key) {
    bool found = true;
    if (this->isBoolIn(key)) {
      this->bools.erase(key);
    } else if (this->isDoubleIn(key)) {
      this->doubles.erase(key);
    } else if (this->isIntIn(key)) {
      this->ints.erase(key);
    } else if (this->isStringIn(key)) {
      this->strings.erase(key);
    } else {
      found = false;
    }
    return found;
  }

  /// if key->bool, return true and set *val to bool in dict
  /// \param key look for this in dict
  /// \param val set *val to bool value assoc with key
  /// \returns true if key in dict, false otherwise
  bool Dict::get(std::string key, bool * val) {
    std::map<std::string, bool>::iterator it;
    it = this->bools.find(key);
    bool found = false;
    if (it != bools.end()) {
      found = true;
      *val = it->second;
    }
    return found;
  }

  /// map key->val in dict, return true if key already in dict
  /// \param key name for new val
  /// \param val value in dict assoc with key
  /// \returns true if key already in dict, false otherwise
  bool Dict::set(std::string key, bool val) {
    bool found = this->remove(key);
    this->bools.insert(std::pair<std::string, bool>(key, val));
    return found;
  }

  /// if key->double, return true and set *val to double in dict
  /// \param key look for this in dict
  /// \param val set *val to double value assoc with key
  /// \returns true if key in dict, false otherwise
  bool Dict::get(std::string key, double * val) {
    std::map<std::string, double>::iterator it;
    it = this->doubles.find(key);
    bool found = false;
    if (it != doubles.end()) {
      found = true;
      *val = it->second;
    }
    return found;
  }

  /// map key->val in dict, return true if key already in dict
  /// \param key name for new val
  /// \param val value in dict assoc with key
  /// \returns true if key already in dict, false otherwise
  bool Dict::set(std::string key, double val) {
    bool found = this->remove(key);
    this->doubles.insert(std::pair<std::string, double>(key, val));
    return found;
  }

  /// if key->int, return true and set *val to int in dict
  /// \param key look for this in dict
  /// \param val set *val to int value assoc with key
  /// \returns true if key in dict, false otherwise
  bool Dict::get(std::string key, int * val) {
    std::map<std::string, int>::iterator it;
    it = this->ints.find(key);
    bool found = false;
    if (it != ints.end()) {
      found = true;
      *val = it->second;
    }
    return found;
  }

  /// map key->val in dict, return true if key already in dict
  /// \param key name for new val
  /// \param val value in dict assoc with key
  /// \returns true if key already in dict, false otherwise
  bool Dict::set(std::string key, int val) {
    bool found = this->remove(key);
    this->ints.insert(std::pair<std::string, int>(key, val));
    return found;
  }

  /// if key->str, return true and set *val to str in dict
  /// \param key look for this in dict
  /// \param val set *val to str value assoc with key
  /// \returns true if key in dict, false otherwise
  bool Dict::get(std::string key, std::string * val) {
    std::map<std::string, std::string>::iterator stringsIt;
    stringsIt = this->strings.find(key);
    bool found = false;
    if (stringsIt != strings.end()) {
      found = true;
      *val = stringsIt->second;
    }
    return found;
  }

  /// map key->val in dict, return true if key already in dict
  /// \param key name for new val
  /// \param val value in dict assoc with key
  /// \returns true if key already in dict, false otherwise
  bool Dict::set(std::string key, std::string val) {
    bool found = this->remove(key);
    this->strings.insert(std::pair<std::string, std::string>(key, val));
    return found;
  }
}  // namespace fict

/// allocate a new dictionary
/// \return the new Dict instance
fict::Dict * dict_new() {
  fict::Dict * out_dict = new fict::Dict();
  return out_dict;
}

/// free memory associated with a dictionary
/// \param to_free the Dict that will be deleted from memory
void dict_free(fict::Dict * to_free) {
  delete to_free;
}

/// map a key to a bool in a given dictionary
/// \param dict key->val will be inserted into this dictionary
/// \param key null terminated name for val
/// \param val mapped to key in dict
/// \return true if key is already in dict, false otherwise
bool dict_set_bool(fict::Dict * dict,
                   const char * key,
                   bool val) {
  return dict->set(std::string(key), val);
}

/// map a key to a double in a given dictionary
/// \param dict key->val will be inserted into this dictionary
/// \param key null terminated name for val
/// \param val mapped to key in dict
/// \return true if key is already in dict, false otherwise
bool dict_set_double(fict::Dict * dict,
                     const char * key,
                     double val) {
  return dict->set(std::string(key), val);
}

/// map a key to a int in a given dictionary
/// \param dict key->val will be inserted into this dictionary
/// \param key null terminated name for val
/// \param val mapped to key in dict
/// \return true if key is already in dict, false otherwise
bool dict_set_int(fict::Dict * dict,
                  const char * key,
                  int val) {
  return dict->set(std::string(key), val);
}

/// map key to C char array (must be null term.) in  dict
/// \param dict key->val will be inserted into this dictionary
/// \param key null terminated name for val
/// \param val (null term) mapped to key
/// \return true if key is already in dict, false otherwise
bool dict_set_string(fict::Dict * dict,
                     const char * key,
                     const char * val) {
  return dict->set(std::string(key), std::string(val));
}

/// if key->bool is in dict, return bool set *found true, else false
/// \param dict find key->bool in this dict
/// \param key (null term) search for key and test if value is a bool
/// \param found if key in dict and val is a bool, set found to true
/// \return the bool pointed to by key in dict, if it exists
bool dict_get_bool(fict::Dict * dict,
                   const char * key,
                   bool * found) {
  bool val = false;
  *found = dict->get(std::string(key), &val);
  return val;
}

/// if key->dbl is in dict, return dbl set *found true, else false
/// \param dict find key->double in this dict
/// \param key (null term) search for key and test if value is a double
/// \param found if key in dict and val is a double, set found to true
/// \return the double pointed to by key in dict, if it exists
double dict_get_double(fict::Dict * dict,
                       const char * key,
                       bool * found) {
  double val = 0.0;
  *found = dict->get(std::string(key), &val);
  return val;
}

/// if key->int is in dict, return int set *found true, else false
/// \param dict find key->int in this dict
/// \param key (null term) search for key and test if value is an int
/// \param found if key in dict and val is an int, set found to true
/// \return the int pointed to by key in dict, if it exists
int dict_get_int(fict::Dict * dict,
                 const char * key,
                 bool * found) {
  int val = 0;
  *found = dict->get(std::string(key), &val);
  return val;
}

/// if key->str is in dict, return str set *found true, else false
/// \param dict find key->str in this dict
/// \param key (null term) search for key and test if value is a str
/// \param found if key in dict and val is a str, set found to true
/// \return the str pointed to by key in dict, if it exists
char * dict_get_string(fict::Dict * dict,
                       const char * key,
                       bool * found) {
  char * retStr = NULL;
  std::string val;
  *found = dict->get(std::string(key), &val);
  if (*found) {
    retStr = new char[val.length() + 1]();
    std::copy(val.begin(), val.end(), retStr);
  }
  return retStr;
}

/// if key is in dict, return true, and remove key->val from dict
/// \param dict delete key->val in this dict, if exists
/// \param key (null term) search for key and remove key->val
/// \return true if key in dict, false otherwise
bool dict_remove(fict::Dict * dict, const char * key) {
  return dict->remove(std::string(key));
}
