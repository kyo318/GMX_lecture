// Copyright 2020 Josh Buckner
#ifndef DICT_H_
#define DICT_H_
#include <map>
#include <string>

namespace fict {
  typedef std::map<std::string, std::string> StringDict;
  typedef std::map<std::string, bool> BoolDict;
  typedef std::map<std::string, double> DoubleDict;
  typedef std::map<std::string, int> IntDict;

/// map a name to an arbitrary value like a python dict
class Dict {
 public:
  Dict() {}
  ~Dict() {}

  /// if key maps to a bool value return true, otherwise false
  /// \param key look for key->bool
  /// \return true if key->bool, false otherwise
  bool isBoolIn(std::string key);

  /// if key maps to a double value return true, otherwise false
  /// \param key look for key->double
  /// \return true if key->double, false otherwise
  bool isDoubleIn(std::string key);

  /// if key maps to a int value return true, otherwise false
  /// \param key look for key->int
  /// \return true if key->int, false otherwise
  bool isIntIn(std::string key);

  /// if key maps to a string value return true, otherwise false
  /// \param key look for key->string
  /// \return true if key->string, false otherwise
  bool isStringIn(std::string key);

  /// if key maps to something in the dict, return true, false otherwise
  /// \param key look for in dict
  /// \return true if key in dict, false otherwise
  bool isIn(std::string key);

  /// if key is in dict, remove key->value pair, and return true
  /// \param key look for this in dict
  /// \return true if key found and removed, false otherwise
  bool remove(std::string key);

  /// if key->bool, return true and set *val to bool in dict
  /// \param key look for this in dict
  /// \param val set *val to bool value assoc with key
  /// \returns true if key in dict, false otherwise
  bool get(std::string key, bool * val);

  /// map key->val in dict, return true if key already in dict
  /// \param key name for new val
  /// \param val value in dict assoc with key
  /// \returns true if key already in dict, false otherwise
  bool set(std::string key, bool val);

  /// if key->double, return true and set *val to double in dict
  /// \param key look for this in dict
  /// \param val set *val to double value assoc with key
  /// \returns true if key in dict, false otherwise
  bool get(std::string key, double * val);

  /// map key->val in dict, return true if key already in dict
  /// \param key name for new val
  /// \param val value in dict assoc with key
  /// \returns true if key already in dict, false otherwise
  bool set(std::string key, double val);

  /// if key->int, return true and set *val to int in dict
  /// \param key look for this in dict
  /// \param val set *val to int value assoc with key
  /// \returns true if key in dict, false otherwise
  bool get(std::string key, int * val);

  /// map key->val in dict, return true if key already in dict
  /// \param key name for new val
  /// \param val value in dict assoc with key
  /// \returns true if key already in dict, false otherwise
  bool set(std::string key, int val);

  /// if key->str, return true and set *val to str in dict
  /// \param key look for this in dict
  /// \param val set *val to str value assoc with key
  /// \returns true if key in dict, false otherwise
  bool get(std::string key, std::string * val);

  /// map key->val in dict, return true if key already in dict
  /// \param key name for new val
  /// \param val value in dict assoc with key
  /// \returns true if key already in dict, false otherwise
  bool set(std::string key, std::string val);

 private:
  StringDict strings;
  BoolDict bools;
  DoubleDict doubles;
  IntDict ints;
};
}  // namespace fict

extern "C" {
/// allocate a new dictionary
/// \return the new Dict instance
fict::Dict * dict_new();

/// free memory associated with a dictionary
/// \param to_free the Dict that will be deleted from memory
void dict_free(fict::Dict * to_free);

/// map a key to a bool in a given dictionary
/// \param dict key->val will be inserted into this dictionary
/// \param key null terminated name for val
/// \param val mapped to key in dict
/// \return true if key is already in dict, false otherwise
bool dict_set_bool(fict::Dict * dict,
                   const char * key,
                   bool val);

/// map a key to a double in a given dictionary
/// \param dict key->val will be inserted into this dictionary
/// \param key null terminated name for val
/// \param val mapped to key in dict
/// \return true if key is already in dict, false otherwise
bool dict_set_double(fict::Dict * dict,
                     const char * key,
                     double val);

/// map a key to a int in a given dictionary
/// \param dict key->val will be inserted into this dictionary
/// \param key null terminated name for val
/// \param val mapped to key in dict
/// \return true if key is already in dict, false otherwise
bool dict_set_int(fict::Dict * dict,
                  const char * key,
                  int val);

/// map key to C char array (must be null term.) in  dict
/// \param dict key->val will be inserted into this dictionary
/// \param key null terminated name for val
/// \param val (null term) mapped to key
/// \return true if key is already in dict, false otherwise
bool dict_set_string(fict::Dict * dict,
                     const char * key,
                     const char * val);

/// if key->bool is in dict, return bool set *found true, else false
/// \param dict find key->bool in this dict
/// \param key (null term) search for key and test if value is a bool
/// \param found if key in dict and val is a bool, set found to true
/// \return the bool pointed to by key in dict, if it exists
bool dict_get_bool(fict::Dict * dict,
                   const char * key,
                   bool * found);

/// if key->dbl is in dict, return dbl set *found true, else false
/// \param dict find key->double in this dict
/// \param key (null term) search for key and test if value is a double
/// \param found if key in dict and val is a double, set found to true
/// \return the double pointed to by key in dict, if it exists
double dict_get_double(fict::Dict * dict,
                       const char * key,
                       bool * found);

/// if key->int is in dict, return int set *found true, else false
/// \param dict find key->int in this dict
/// \param key (null term) search for key and test if value is an int
/// \param found if key in dict and val is an int, set found to true
/// \return the int pointed to by key in dict, if it exists
int dict_get_int(fict::Dict * dict,
                 const char * key,
                 bool * found);

/// if key->str is in dict, return str set *found true, else false
/// \param dict find key->str in this dict
/// \param key (null term) search for key and test if value is a str
/// \param found if key in dict and val is a str, set found to true
/// \return the str pointed to by key in dict, if it exists
char * dict_get_string(fict::Dict * dict,
                       const char * key,
                       bool * found);

/// if key is in dict, return true, and remove key->val from dict
/// \param dict delete key->val in this dict, if exists
/// \param key (null term) search for key and remove key->val
/// \return true if key in dict, false otherwise
  bool dict_remove(fict::Dict * dict, const char * key);
}
#endif  // DICT_H_
