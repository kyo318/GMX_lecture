int init_charmm();

// read data into charmm
int read_rtf_file(char * filename, int * len);
int read_param_file(char * filename, int * len);
int read_sequence_string(char * seq_str, int * len_seq_str);

// generate psf commands
int generate_setup(char * segid, int * len_segid);

// internal coordinate commands
int ic_fill_from_param_file(int * all_flag);
int ic_print();
int ic_edit_dihedral(int * res_num1, char * atom_name1,
                     int * res_num2, char * atom_name2,
                     int * res_num3, char * atom_name3,
                     int * res_num4, char * atom_name4,
                     double * new_psi);
int ic_edit_angle(int * res_num1, char * atom_name1,
                  int * res_num2, char * atom_name2,
                  int * res_num3, char * atom_name3,
                  double * new_angle);
int ic_edit_dist(int * res_num1, char * atom_name1,
                 int * res_num2, char * atom_name2,
                 double * new_dist);
int ic_seed(int * res_num1, char * atom_name1,
            int * res_num2, char * atom_name2,
            int * res_num3, char * atom_name3);
int ic_build();

// COORdinate manipulation commands
int coor_orient(int * mass_flag, int * rms_flag, int * noro_flag);
int coor_print();

// energy commands
typedef enum {
  TOTE   =  1, TOTKE  =  2, EPOT   =  3, TEMPS  =  4,
  GRMS   =  5, BPRESS =  6, PJNK1  =  7, PJNK2  =  8,
  PJNK3  =  9, PJNK4  = 10, HFCTE  = 11, HFCKE  = 12,
  EHFC   = 13, EWORK  = 11, VOLUME = 15, PRESSE = 16,
  PRESSI = 17, VIRI   = 18, VIRE   = 19, VIRKE  = 20,
  TEPR   = 21, PEPR   = 22, KEPR   = 23, KEPR2  = 24,
  DROFFA = 26, XTLTE  = 27, XTLKE  = 28,
  XTLPE  = 29, XTLTEM = 30, XTLPEP = 31, XTLKEP = 32,
  XTLKP2 = 33,
  TOT4   = 37, TOTK4  = 38, EPOT4  = 39, TEM4   = 40,
  MBMOM  = 41, BODYT  = 42, PARTT  = 43,
  SELF   = 45, SCREEN = 46, COUL   = 47,
  SOLV   = 48, INTER  = 49,
  FQKIN  = 50,
  CGKE   = 51, CGPOT  = 52, ALLK= 53, ALLP = 54,
  ALLE   = 55, SDMIN  = 56,
  DIPK   = 57, DIPT  = 58,
  PHKIN  = 59
} energy_property_type;

typedef enum {
  BOND   =  1, ANGLE  =  2, UREYB  =  3, DIHE   =  4,
  IMDIHE =  5, VDW    =  6, ELEC   =  7, HBOND  =  8,
  USER   =  9, CHARM  = 10, CDIHE  = 11, CINTCR = 12,
  CQRT   = 13, NOE    = 14, SBNDRY = 15, IMVDW  = 16,
  IMELEC = 17, IMHBND = 18, EWKSUM = 19, EWSELF = 20,
  EXTNDE = 21, RXNFLD = 22, ST2    = 23, IMST2  = 24,
  TSM    = 25, QMEL   = 26, QMVDW  = 27, ASP    = 28,
  EHARM  = 29, GEO    = 30, MDIP   = 31, PINT   = 32,
  PRMS   = 33, PANG   = 34, SSBP   = 35, BK4D   = 36,
  SHEL   = 37, RESD   = 38, SHAP   = 39, STRB   = 40,
  OOPL   = 41, PULL   = 42, POLAR  = 43, DMC    = 44,
  RGY    = 45, EWEXCL = 46, EWQCOR = 47, EWUTIL = 48,
  PBELEC = 49, PBNP   = 50, MBDEFRM= 51, MBELEC = 52,
  STRSTR = 53, BNDBND = 54, BNDTW  = 55, EBST   = 56,
  MBST   = 57, BBT    = 58, SST    = 59, GBENR  = 60,
  HMCM   = 61, ADUMB  = 62, HYDR   = 63, GSBP   = 64,
  FQPOL  = 65, GRVDW  = 66, GRELEC = 67, SASTRM = 68,
  CMAP   = 69, ELRC   = 70, QOVLAP = 71, PIPF   = 72,
  UMBR   = 73,
  RUSHREPU = 74, RUSHPHOB = 75, RUSHHBND = 76,
  RUSHBDON = 77, RUSHBACC = 78, RUSHAROM = 79,
  PHENR  = 80, MMPT   = 83, VMOD   = 84, CROS   = 85,
  PNME   = 86, IFCTPOL = 87, IFCTNPL = 88, PATH   = 89,
  PMF1D = 90, PMF2D = 91, PRIMO = 92, VALB = 93,
  EDS = 94,
  ECHDL = 95, ECHAN = 96, ECHTN = 97, ECHRN = 98,
  CPUCK = 99, SMBP = 100, GAMUS = 101, EEMAP = 102,
  MRMD = 103, CSPRES = 104, ECS = 105, ERDC = 106,
  DEFE = 107
} energy_term_type;

int print_energy();
double get_energy_property(energy_property_type * property_index);
double get_energy_term(energy_term_type * term_index);
