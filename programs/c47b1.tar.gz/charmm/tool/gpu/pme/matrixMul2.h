#ifndef _MATRIXMUL_H_
#define _MATRIXMUL_H_

#define BLOCK_SIZE 16
#define THD 256
#define THD3 64
#define HALF 16
#define SHK 3
#define SITE 3
#define ITR_MAX 50

#endif // _MATRIXMUL_H_

