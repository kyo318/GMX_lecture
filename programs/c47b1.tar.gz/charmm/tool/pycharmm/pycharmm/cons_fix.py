# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""functions to configure harmonic constraints

Functions
---------
- `turn_off` -- turn off fix constraints
- `setup` -- turn on fix constraints
"""

import ctypes

import pycharmm
import pycharmm.lib as lib


def turn_off(comparison=False):
    """turn off and clear settings for fix constraints

    :param bool comparison: if true, turn off fix contraints on the comparison set
    :return bool: True <==> success
    """
    none_selected = pycharmm.SelectAtoms()
    status = setup(none_selected, comparison)
    return status


def setup(selection, comparison=False, purge=False,
          bond=False, angle=False, phi=False, imp=False, cmap=False):
    """configure and turn on fix constraints for the selected atoms

    :param pycharmm.SelectAtoms selection: selection[i] == 1 <=> apply restraints to atom i
    :param bool comparison: if true, do restraints on comparison set instead of main set
    :param bool purge: if true, use the purge option which modified the PSF irrevocably
    :param bool bond: if true, use the bond option
    :param bool angle: if true, use the angle option
    :param bool phi: if true, use the phi option
    :param bool imp: if true, use the imp option
    :param bool cmap: if true, use the cmap option
    :return bool: True <==> success
    """
    c_sel = selection.as_ctypes()

    c_comp = ctypes.c_int(comparison)
    c_purge = ctypes.c_int(purge)
    c_bond = ctypes.c_int(bond)
    c_angle = ctypes.c_int(angle)
    c_phi = ctypes.c_int(phi)
    c_imp = ctypes.c_int(imp)
    c_cmap = ctypes.c_int(cmap)

    status = lib.charmm.cons_fix_setup(c_sel,
                                       ctypes.byref(c_comp),
                                       ctypes.byref(c_purge),
                                       ctypes.byref(c_bond),
                                       ctypes.byref(c_angle),
                                       ctypes.byref(c_phi),
                                       ctypes.byref(c_imp),
                                       ctypes.byref(c_cmap))
    status = bool(status)
    return status
