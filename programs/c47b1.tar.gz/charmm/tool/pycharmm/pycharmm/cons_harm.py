# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""functions to configure harmonic constraints

Functions
---------
- `turn_off` -- turn off and clear settings
- `setup_absolute` -- use absolute harmonic restraints
- `setup_best_fit` -- use best fit harmonic restraints
- `setup_relative` -- use relative harmonic restraints
"""

import ctypes

import pycharmm
import pycharmm.lib as lib


_OPTIONS_fields = [('expo', ctypes.c_int),
                   ('x_scale', ctypes.c_double),
                   ('y_scale', ctypes.c_double),
                   ('z_scale', ctypes.c_double),
                   ('q_no_rot', ctypes.c_int),
                   ('q_no_trans', ctypes.c_int),
                   ('q_mass', ctypes.c_int),
                   ('q_weight', ctypes.c_int),
                   ('force_const', ctypes.c_double)]


class _OPTIONS(ctypes.Structure):
    """A ctypes struct to hold harmonic constraint settings

    Attributes:
        expo exponent on diff between atom and ref atom
        x_scale global scale factor for the x component
        y_scale global scale factor for the y component
        z_scale global scale factor for the z component
        q_no_rot do not do rotational restraint
        q_no_trans do not do translational restraint
        q_mass multiply k by atom mass (natural freq of oscillation of sqrt(k))
        q_weight use weight array for k(i) and not force argument above
        force_const restraint force constant k
    """
    _fields_ = _OPTIONS_fields


_OPTIONS_defaults = (2, 1.0, 1.0, 1.0, 0, 0, 0, 0, 0.0)

# TODO:
# 1. separate fill structure routine in util.py
# 2. add more error checking (eg relative:
#    check that sum(iselect) == sum(jselect))


def turn_off():
    """turn off and clear settings for harmonic constraints

    :return bool: True <==> success
    """
    status = lib.charmm.cons_harm_turn_off()
    bool(status)
    return status


def _make_opts(fields, settings):
    """make a new instance of _OPTIONS

    :param list[string] fields: list of valid field names used to filter settings
    :param dict settings: name and value for harmonic restraints settings
    :return OPTIONS: an instance filled with values from settings
    """
    new_opts = _OPTIONS(*_OPTIONS_defaults)
    fields_types = dict(_OPTIONS_fields)
    valid_settings = [(k, v) for k, v in settings.items() if k in fields]
    for k, v in valid_settings:
        setattr(new_opts, k, fields_types[k](v))  # TODO: need a try/catch here

    return new_opts


def setup_absolute(selection=None, comparison=False, **kwargs):
    """configure and turn on absolute harmonic constraints for the selected atoms

    valid key word arguments for settings include
    expo, x_scale, y_scale, z_scale, q_mass, q_weight, and force_const

    :param pycharmm.SelectAtoms selection: apply restraints to selected atoms; None -> all atoms
    :param bool comparison: if true, do restraints on comparison set instead of main set
    :param kwargs: key word arguments for absolute harmonic constraints
    :return bool: True <==> success
    """
    if not selection:
        selection = pycharmm.SelectAtoms().all_atoms()

    abs_fields = ['expo', 'x_scale', 'y_scale', 'z_scale',
                  'q_mass', 'q_weight', 'force_const']
    opts = _make_opts(abs_fields, kwargs)

    c_sel = selection.as_ctypes()
    c_comp = ctypes.c_int(comparison)
    status = lib.charmm.cons_harm_setup_absolute(c_sel,
                                                 ctypes.byref(c_comp),
                                                 ctypes.byref(opts))
    status = bool(status)
    return status


def setup_best_fit(selection=None, comparison=False, **kwargs):
    """configure and turn on best fit harmonic constraints for the selected atoms

    valid key word arguments for settings include
    q_no_rot, q_no_trans, q_mass, q_weight, force_const

    :param pycharmm.SelectAtoms selection: apply restraints to selected atoms
    :param bool comparison: if true, do restraints on comparison set instead of main set
    :param kwargs: key word arguments for best fit harmonic constraints
    :return bool: True <==> success
    """
    if not selection:
        selection = pycharmm.SelectAtoms().all_atoms()

    best_fit_fields = ['q_no_rot', 'q_no_trans',
                       'q_mass', 'q_weight', 'force_const']
    opts = _make_opts(best_fit_fields, kwargs)

    c_sel = selection.as_ctypes()
    c_comp = ctypes.c_int(comparison)
    status = lib.charmm.cons_harm_setup_best_fit(c_sel,
                                                 ctypes.byref(c_comp),
                                                 ctypes.byref(opts))
    status = bool(status)
    return status


def setup_relative(iselection, jselection, comparison=False, **kwargs):
    """configure and turn on relative harmonic constraints for the selected atoms

    valid key word arguments for settings include
    q_no_rot, q_no_trans, q_mass, q_weight, force_const

    :param pycharmm.SelectAtoms iselection: apply restraints to selected atoms
    :param pycharmm.SelectAtoms jselection: apply restraints to selected atoms
    :param bool comparison: if true, do restraints on comparison set instead of main set
    :param kwargs: key word arguments for relative harmonic constraints
    :return bool: True <==> success
    """
    relative_fields = ['q_no_rot', 'q_no_trans',
                       'q_mass', 'q_weight', 'force_const']
    opts = _make_opts(relative_fields, kwargs)

    c_isel = iselection.as_ctypes()
    c_jsel = jselection.as_ctypes()
    c_comp = ctypes.c_int(comparison)
    status = lib.charmm.cons_harm_setup_relative(c_isel, c_jsel,
                                                 ctypes.byref(c_comp),
                                                 ctypes.byref(opts))
    status = bool(status)
    return status
