# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""functions to configure various constraints/restraints covering:
   cons dihe
   cons cldh
   cons ic
   cons dropet
   cons hmcm

"""
import ctypes
import pycharmm.lib as lib
import pycharmm.script

def dihe(selection='', cldh=False, force=0, **kwargs):
    """Set-up/turn-off dihedral angle restraints
    selection = string
         ['bynum int int int int'] ['4x(segid resid iupac)'] ['4x(resnumber iupac)']
    force=<real>
    **kwargs: minimum=<real> period=<int> width=<real> comp=<bool> main=<bool>
    """

    if not cldh and len(selection)>0:
        cons_command = 'cons dihe ' + str(selection)
        cons_dihe = pycharmm.script.CommandScript(cons_command,
                                                  force=force,
                                                  **kwargs)
    else:
        cons_dihe =  pycharmm.script.CommandScript('cons cldh')
    cons_dihe.run()

def ic(**kwargs):
    """Impose internal coordinate restraints
    **kwargs:
             [bond=<real> [exponemt=<int>] [upper=<bool>]]
             [angle=<real>]
             [dihedral=<real>]
             [improper=<real>]
    """
    cons_ic = pycharmm.script.CommandScript('cons ic', **kwargs)
    cons_ic.run()

def droplet(**kwargs):
    """Impose quartic droplet restraints
    **kwargs:
             force=<real>
             exponent=<int>
             nomass=<bool>
    """
    cons_droplet = pycharmm.script.CommandScript('cons droplet', **kwargs)
    cons_droplet.run()

