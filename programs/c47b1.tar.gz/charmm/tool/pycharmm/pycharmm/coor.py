# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""functions for moving some or all of the atoms

Classes
---------
- `Coordinates`  -- manipulate coord sets in python and talk to charmm

Functions
---------
- `get_natom` -- return the number of atoms in the simulation
- `get_positions` -- return the atom positions in a [0:3, 0:natom] numpy array
- `set_positions` -- set the atom positions from a [0:3, 0:natom] numpy array
- `orient` -- modifies coordinates of all atoms according to the passed flags
- `show` -- print the main coordinate set of the atoms
- `set_weights` -- sets the weights of the atoms in the simulation
- `get_weights` -- gets the weights of the atoms in the simulation
- `copy_forces` -- copy the forces to the comparison set
- `set_forces` -- sets the forces of the atoms
- `get_forces` -- gets the forces of the atoms
- `set_comparison` -- set the comparison set in charmm
- `get_comparison` -- gets the comparison of the atoms
- `show_comp` -- print the comparison set of the atoms
- `stat` -- computes max, min, ave for x, y, z, w over selection of main or comp sets
"""

import ctypes
import typing

import pandas

import pycharmm
import pycharmm.lib as lib


def get_natom():
    """returns the number of atoms currently in the simulation

    :return int: number of atoms currently in the simulation
    """
    natom = lib.charmm.coor_get_natom()
    return natom


def set_positions(pos):
    """sets the positions of the atoms in the simulation

    :param pandas.core.frame.DataFrame pos: a dataframe with columns named x, y and z
    :return int: number of atoms in the simulation
    """
    natom = get_natom()
    pos_x = pos['x'][0:natom].tolist()
    pos_y = pos['y'][0:natom].tolist()
    pos_z = pos['z'][0:natom].tolist()

    c_x = (ctypes.c_double * natom)(*pos_x)
    c_y = (ctypes.c_double * natom)(*pos_y)
    c_z = (ctypes.c_double * natom)(*pos_z)

    natom = lib.charmm.coor_set_positions(c_x, c_y, c_z)
    return natom


def get_positions():
    """gets the positions of the atoms in the simulation

    :return pandas.core.frame.DataFrame: a dataframe with columns named x, y and z
    """
    natom = get_natom()
    c_x = (ctypes.c_double * natom)()
    c_y = (ctypes.c_double * natom)()
    c_z = (ctypes.c_double * natom)()

    lib.charmm.coor_get_positions(c_x, c_y, c_z)

    pos_x = [c_x[i] for i in range(natom)]
    pos_y = [c_y[i] for i in range(natom)]
    pos_z = [c_z[i] for i in range(natom)]

    pos = pandas.DataFrame({'x': pos_x, 'y': pos_y, 'z': pos_z})
    return pos


def set_weights(weights):
    """sets the weights of the atoms in the simulation

    :param list[float] weights: list of one weight for each atom 0:natom
    :return int: number of atoms in the simulation
    """
    natom = get_natom()
    c_weights = (ctypes.c_double * natom)(*weights)
    natom = lib.charmm.coor_set_weights(c_weights)
    return natom


def get_weights():
    """gets the weights of the atoms in the simulation

    :return list[float]: a list of float atom weights 0:natom
    """
    natom = get_natom()
    c_weights = (ctypes.c_double * natom)()
    lib.charmm.coor_get_weights(c_weights)

    weights = [c_weights[i] for i in range(natom)]
    return weights


def copy_forces(mass=False, selection=None):
    """copy the forces to the comparison set

    :param bool mass: Whether to weight the forces by mass
    :param pycharmm.SelectAtoms selection: only copy forces of selected atoms
    :return bool: true if successful
    """
    if not selection:
        selection = pycharmm.SelectAtoms().all_atoms()

    c_sel = selection.as_ctypes()
    c_mass = ctypes.c_int(mass)

    status = lib.charmm.coor_copy_forces(ctypes.byref(c_mass), c_sel)

    status = bool(status)
    return status


def set_forces(forces):
    """sets the forces of the atoms

    :param pandas.core.frame.DataFrame forces: a dataframe with columns named dx, dy and dz
    :return int: number of atoms in the simulation
    """
    natom = get_natom()
    dx = forces['dx'][0:natom].tolist()
    dy = forces['dy'][0:natom].tolist()
    dz = forces['dz'][0:natom].tolist()

    c_dx = (ctypes.c_double * natom)(*dx)
    c_dy = (ctypes.c_double * natom)(*dy)
    c_dz = (ctypes.c_double * natom)(*dz)

    natom = lib.charmm.coor_set_forces(c_dx, c_dy, c_dz)
    return natom


def get_forces():
    """gets the forces of the atoms

    :return pandas.core.frame.DataFrame: a dataframe with columns named dx, dy and dz
    """
    natom = get_natom()
    c_dx = (ctypes.c_double * natom)()
    c_dy = (ctypes.c_double * natom)()
    c_dz = (ctypes.c_double * natom)()

    lib.charmm.coor_get_forces(c_dx, c_dy, c_dz)

    dx = [c_dx[i] for i in range(natom)]
    dy = [c_dy[i] for i in range(natom)]
    dz = [c_dz[i] for i in range(natom)]

    forces = pandas.DataFrame({'dx': dx, 'dy': dy, 'dz': dz})
    return forces


def set_comparison(pos):
    """set the comparison set in charmm

    :param pandas.core.frame.DataFrame pos: a dataframe with columns named
       x, y, z, and w
    :return int: number of atoms in the simulation
    """
    natom = get_natom()
    x = pos['x'][0:natom].tolist()
    y = pos['y'][0:natom].tolist()
    z = pos['z'][0:natom].tolist()
    w = pos['w'][0:natom].tolist()

    x = (ctypes.c_double * natom)(*x)
    y = (ctypes.c_double * natom)(*y)
    z = (ctypes.c_double * natom)(*z)
    w = (ctypes.c_double * natom)(*w)

    natom = lib.charmm.coor_set_comparison(x, y, z, w)
    return natom


def get_comparison():
    """gets the comparison of the atoms

    :return pandas.core.frame.DataFrame: a dataframe with columns named
       x, y, z, and w
    """
    natom = get_natom()
    x = (ctypes.c_double * natom)()
    y = (ctypes.c_double * natom)()
    z = (ctypes.c_double * natom)()
    w = (ctypes.c_double * natom)()

    lib.charmm.coor_get_comparison(x, y, z, w)

    x = [x[i] for i in range(natom)]
    y = [y[i] for i in range(natom)]
    z = [z[i] for i in range(natom)]
    w = [w[i] for i in range(natom)]

    pos = pandas.DataFrame({'x': x,
                            'y': y,
                            'z': z,
                            'w': w})
    return pos


def set_comp2(pos):
    """set the comp2 set in charmm

    :param pandas.core.frame.DataFrame pos: a dataframe with columns named
       x, y, z, and w
    :return int: number of atoms in the simulation
    """
    natom = get_natom()
    x = pos['x'][0:natom].tolist()
    y = pos['y'][0:natom].tolist()
    z = pos['z'][0:natom].tolist()
    w = pos['w'][0:natom].tolist()

    x = (ctypes.c_double * natom)(*x)
    y = (ctypes.c_double * natom)(*y)
    z = (ctypes.c_double * natom)(*z)
    w = (ctypes.c_double * natom)(*w)

    natom = lib.charmm.coor_set_comp2(x, y, z, w)
    return natom


def get_comp2():
    """gets the comp2 of the atoms

    :return pandas.core.frame.DataFrame: a dataframe with columns named
       x, y, z, and w
    """
    natom = get_natom()
    x = (ctypes.c_double * natom)()
    y = (ctypes.c_double * natom)()
    z = (ctypes.c_double * natom)()
    w = (ctypes.c_double * natom)()

    lib.charmm.coor_get_comp2(x, y, z, w)

    x = [x[i] for i in range(natom)]
    y = [y[i] for i in range(natom)]
    z = [z[i] for i in range(natom)]
    w = [w[i] for i in range(natom)]

    pos = pandas.DataFrame({'x': x,
                            'y': y,
                            'z': z,
                            'w': w})
    return pos


def set_main(pos):
    """set the main set in charmm

    :param pandas.core.frame.DataFrame pos: a dataframe with columns named
       x, y, z, and w
    :return int: number of atoms in the simulation
    """
    natom = get_natom()
    x = pos['x'][0:natom].tolist()
    y = pos['y'][0:natom].tolist()
    z = pos['z'][0:natom].tolist()
    w = pos['w'][0:natom].tolist()

    x = (ctypes.c_double * natom)(*x)
    y = (ctypes.c_double * natom)(*y)
    z = (ctypes.c_double * natom)(*z)
    w = (ctypes.c_double * natom)(*w)

    natom = lib.charmm.coor_set_main(x, y, z, w)
    return natom


def get_main():
    """gets the main of the atoms

    :return pandas.core.frame.DataFrame: a dataframe with columns named
       x, y, z, and w
    """
    natom = get_natom()
    x = (ctypes.c_double * natom)()
    y = (ctypes.c_double * natom)()
    z = (ctypes.c_double * natom)()
    w = (ctypes.c_double * natom)()

    lib.charmm.coor_get_main(x, y, z, w)

    x = [x[i] for i in range(natom)]
    y = [y[i] for i in range(natom)]
    z = [z[i] for i in range(natom)]
    w = [w[i] for i in range(natom)]

    pos = pandas.DataFrame({'x': x,
                            'y': y,
                            'z': z,
                            'w': w})
    return pos


# def orient(by_mass, by_rms, by_noro):
#     """modifies coordinates of all atoms according to the passed flags

#     The select set of atoms is first centered about the origin,
#     and then rotated to either align with the axis,
#     or the other coordinate set.
#     The RMS keyword will use the other coordinate set as a rotation reference.
#     The MASS keyword cause a mass weighting to be done. This will
#     align the specified atoms along their moments of inertia. When the RMS
#     keyword is not used, then the structure is rotated so that its principle
#     geometric axis coincides with the X-axis and the next largest coincides
#     with the Y-axis. This command is primarily used for preparing a
#     structure for graphics and viewing. It can also be used for finding
#     RMS differences, and in conjunction with the vibrational analysis.
#         The NOROtation keyword will suppress rotations. In this case,
#     only one coordinate set will be modified.

#     Parameters
#     ----------
#     by_mass : bool
#               if true, causes a mass weighting of coordinates
#     by_rms : bool
#              if true, will use the other coordinate set as a rotation reference
#     by_noro : bool
#               if true, supress rotations; only one coordinate set is modified

#     Returns
#     -------
#     success : bool
#               True indicates success, any other value indicates failure
#     """
#     by_mass_flag = ctypes.c_int(by_mass)
#     by_rms_flag = ctypes.c_int(by_rms)
#     by_noro_flag = ctypes.c_int(by_noro)

#     success = lib.charmm.coor_orient(ctypes.byref(by_mass_flag),
#                                      ctypes.byref(by_rms_flag),
#                                      ctypes.byref(by_noro_flag))
#     success = bool(success)
#     return success


def orient(**kwargs):
    """modifies coordinates of all atoms according to the passed flags

    The select set of atoms is first centered about the origin,
    and then rotated to either align with the axis,
    or the other coordinate set.

    The RMS keyword will use the other coordinate set as a rotation reference.

    The MASS keyword cause a mass weighting to be done. This will
    align the specified atoms along their moments of inertia. When the RMS
    keyword is not used, then the structure is rotated so that its principle
    geometric axis coincides with the X-axis and the next largest coincides
    with the Y-axis. This command is primarily used for preparing a
    structure for graphics and viewing. It can also be used for finding
    RMS differences, and in conjunction with the vibrational analysis.

    The NOROtation keyword will suppress rotations. In this case,
    only one coordinate set will be modified.

    :param kwargs: key words for the coor orient charmm command
    """
    oscript = pycharmm.script.CommandScript('coor', orient=True, **kwargs)
    oscript.run()


def show_comp():
    """print the comparison set of the atoms

    :return bool: true if successful
    """
    status = lib.charmm.coor_print_comp()
    status = bool(status)
    return status


def show():
    """print the main coordinate set of the atoms

    :return bool: true if successful
    """
    status = lib.charmm.coor_print()
    bool(status)
    return status


def stat(selection=None, comp=False, mass=False):
    """computes max, min, ave for x, y, z, w over selection of main or comp sets

    :param pycharmm.SelectAtoms selection: a selection of atom indexes to use for stats
    :param bool comp: if true, stats computed for comparison set selection
    :param bool mass: if true, will place the average values at the center of mass
    :return dict: keys xmin, xmax, xave, ymin, ymax, yave, zmin, zmax, zave, wmin, wmax, wave, n_selected, n_misses
    """
    c_comp = ctypes.c_int(comp)
    c_mass = ctypes.c_int(mass)

    if selection is None:
        selection = pycharmm.SelectAtoms().all_atoms()

    c_sel = selection.as_ctypes()

    n_stats = 13
    max_label = 5

    vals = (ctypes.c_double * n_stats)()

    labels_bufs = [ctypes.create_string_buffer(max_label)
                   for _ in range(n_stats)]
    labels_ptrs = (ctypes.c_char_p * n_stats)(*map(ctypes.addressof,
                                                   labels_bufs))

    n_sel = ctypes.c_int(0)
    n_misses = ctypes.c_int(0)

    lib.charmm.coor_stat(c_sel,
                         ctypes.byref(c_comp), ctypes.byref(c_mass),
                         labels_ptrs, vals,
                         ctypes.byref(n_sel), ctypes.byref(n_misses))

    labels_str = [label.value.decode(errors='ignore')
                  for label in labels_bufs[0:n_stats]]
    labels = [label.strip().lower() for label in labels_str]
    labels = [label for label in labels if label]

    stats = dict(zip(labels, vals))
    stats['n_selected'] = n_sel.value
    stats['n_misses'] = n_misses.value
    return stats

# not compat with python 3.7
# CoordSet = typing.Literal['main', 'comp', 'comp2']


class Coordinates:
    __slots__ = 'which_set', 'coords', 'are_dirty'

    def __init__(self, coord_set):
        self.which_set = coord_set
        self.coords = pandas.DataFrame(columns=['x', 'y', 'z', 'w'])
        self.are_dirty = True
        self.pull()

    def pull(self):
        if self.which_set is 'main':
            self.coords = get_main()
        elif self.which_set is 'comp':
            self.coords = get_comparison()
        elif self.which_set is 'comp2':
            self.coords = get_comp2()
        else:
            msg = '{} is not a valid coordinate set'.format(self.which_set)
            raise ValueError(msg)

        self.are_dirty = False
        return self

    def push(self):
        if self.which_set is 'main':
            set_main(self.coords)
        elif self.which_set is 'comp':
            set_comparison(self.coords)
        elif self.which_set is 'comp2':
            set_comp2(self.coords)
        else:
            msg = '{} is not a valid coordinate set'.format(self.which_set)
            raise ValueError(msg)

        self.are_dirty = False
        return self

    def __len__(self):
        return len(self.coords)
