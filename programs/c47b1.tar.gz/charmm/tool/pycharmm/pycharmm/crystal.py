# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""Build a crystal with any space group symmetry,
   optimise its lattice parameters and
   molecular coordinates and
   carry out a vibrational analysis using the options.

Functions
---------
- `define_cubic` -- defines a cubic lattice for a new crystal
- `define_tetra` -- defines a tetragonal lattice for a new crystal
- `define_ortho` -- defines a orthorhombic lattice for a new crystal
- `define_mono` -- defines a monoclinic lattice for a new crystal
- `define_tri` -- defines a triclinic lattice for a new crystal
- `define_hexa` -- defines a hexagonal lattice for a new crystal
- `define_rhombo` -- defines a rhombohedral lattice for a new crystal
- `define_octa` -- defines a octahedral lattice for a new crystal
- `define_rhdo` -- defines a rhombic dodecahedron lattice for a new crystal
"""

import ctypes
import pycharmm.lib as lib


def define_cubic(length):
    """defines a cubic lattice and constants for a new crystal

    :param float length: length of all sides
    :return bool: True for success, otherwise False
    """
    length = ctypes.c_double(length)
    success = lib.charmm.crystal_define_cubic(ctypes.byref(length))
    return success


def define_tetra(length_a, length_c):
    """defines a tetragonal lattice and constants for a new crystal

    The alpha, beta and gamma angles are all 90.0 degrees.
    The length of sides a and b are equal.

    :param float length_a: length of sides a and b
    :param float length_c: length of side c
    :return bool: True for success, otherwise False
    """
    length_a = ctypes.c_double(length_a)
    length_c = ctypes.c_double(length_c)
    success = lib.charmm.crystal_define_tetra(ctypes.byref(length_a),
                                              ctypes.byref(length_c))
    return success


def define_ortho(length_a, length_b, length_c):
    """defines a orthorhombic lattice and constants for a new crystal

    The alpha, beta and gamma angles are all 90.0 degrees.

    :param float length_a: length of side a
    :param float length_b: length of side b
    :param float length_c: length of side c
    :return bool: True for success, otherwise False
    """
    length_a = ctypes.c_double(length_a)
    length_b = ctypes.c_double(length_b)
    length_c = ctypes.c_double(length_c)
    success = lib.charmm.crystal_define_ortho(ctypes.byref(length_a),
                                              ctypes.byref(length_b),
                                              ctypes.byref(length_c))
    return success


def define_mono(length_a, length_b, length_c, angle_beta):
    """defines a monoclinic lattice and constants for a new crystal

    The alpha and gamma angles are both 90.0 degrees.

    :param float length_a: length of side a
    :param float length_b: length of side b
    :param float length_c: length of side c
    :param float angle_beta: measure of angle beta in degrees
    :return bool: True for success, otherwise False
    """
    length_a = ctypes.c_double(length_a)
    length_b = ctypes.c_double(length_b)
    length_c = ctypes.c_double(length_c)
    angle_beta = ctypes.c_double(angle_beta)
    success = lib.charmm.crystal_define_ortho(ctypes.byref(length_a),
                                              ctypes.byref(length_b),
                                              ctypes.byref(length_c),
                                              ctypes.byref(angle_beta))
    return success


def define_tri(length_a, length_b, length_c,
               angle_alpha, angle_beta, angle_gamma):
    """defines a triclinic lattice and constants for a new crystal

    :param float length_a: length of side a
    :param float length_b: length of side b
    :param float length_c: length of side c
    :param float angle_alpha: measure of angle alpha in degrees
    :param float angle_beta: measure of beta alpha in degrees
    :param float angle_gamma: measure of gamma alpha in degrees
    :return bool: True for success, otherwise False
    """
    length_a = ctypes.c_double(length_a)
    length_b = ctypes.c_double(length_b)
    length_c = ctypes.c_double(length_c)
    angle_alpha = ctypes.c_double(angle_alpha)
    angle_beta = ctypes.c_double(angle_beta)
    angle_gamma = ctypes.c_double(angle_gamma)
    success = lib.charmm.crystal_define_ortho(ctypes.byref(length_a),
                                              ctypes.byref(length_b),
                                              ctypes.byref(length_c),
                                              ctypes.byref(angle_alpha),
                                              ctypes.byref(angle_beta),
                                              ctypes.byref(angle_gamma))
    return success


def define_hexa(length_a, length_c):
    """defines a hexagonal lattice and constants for a new crystal

    :param float length_a: lengths of sides a and b
    :param float length_c: length of side c
    :return bool: True for success, otherwise False
    """
    length_a = ctypes.c_double(length_a)
    length_c = ctypes.c_double(length_c)
    success = lib.charmm.crystal_define_hexa(ctypes.byref(length_a),
                                             ctypes.byref(length_c))
    return success


def define_rhombo(length, angle):
    """defines a rhombohedral lattice and constants for a new crystal

    :param float length: length of each side
    :param float angle: measure of each angle in degrees, must be between 0 and 120
    :return bool: True for success, otherwise False
    """
    if angle <= 0.0 or angle >= 120.0:
        raise ValueError("Value %d out of range (0.0, 120.0)" % (angle,))

    length = ctypes.c_double(length)
    angle = ctypes.c_double(angle)
    success = lib.charmm.crystal_define_rhombo(ctypes.byref(length),
                                               ctypes.byref(angle))
    return success


def define_octa(length):
    """defines a octahedral lattice and constants for a new crystal

    :param float length: the length of each side
    :return bool: True for success, otherwise False
    """
    length = ctypes.c_double(length)
    success = lib.charmm.crystal_define_octa(ctypes.byref(length))
    return success


def define_rhdo(length):
    """defines a rhombic dodecahedron lattice and constants for a new crystal

    :param float length: the length of each side
    :return bool: True for success, otherwise False
    """
    length = ctypes.c_double(length)
    success = lib.charmm.crystal_define_rhdo(ctypes.byref(length))
    return success


def build(cutoff, sym_ops=None):
    """brief build the crystal by repeatedly appling specified transformations

    :param float cutoff: images within cutoff distance are included in transformation list
    :param list[string] sym_ops: transformations in (X, Y, Z) format
    :return bool: True for success, otherwise False
    """
    if sym_ops is None:
        sym_ops = []

    nops = len(sym_ops)

    str_array = (ctypes.c_char_p * nops)()
    for i, sym_op in enumerate(sym_ops):
        str_array[i] = sym_op.encode('utf-8')

    cutoff = ctypes.c_double(cutoff)
    nops = ctypes.c_int(nops)

    success = lib.charmm.crystal_build(ctypes.byref(cutoff),
                                       ctypes.byref(str_array),
                                       ctypes.byref(nops))
    return success
