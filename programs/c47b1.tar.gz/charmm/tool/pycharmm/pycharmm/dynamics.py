# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""functions to configure and run molecular dynamics

Functions
---------
- `use_lang` -- use Langevin dynamics
- `use_start` -- use starting velocities described by iasvel
- `set_nprint` -- change step freq to print and store energy data during runs
- `get_nprint` -- return step freq to print and store energy data during runs
- `set_nstep` -- change the number of steps to be taken in each dynamics run
- `get_nstep` -- return the number of steps to be taken in each dynamics run
- `set_inbfrq` -- change the freq of regenerating nonbonded list during runs
- `set_ihbfrq` -- change the freq of regenerating the hydrogen bond list
- `set_timest` -- set the time step for dynamics
- `set_akmast` -- set the time step for dynamics in AKMA units
- `set_firstt` -- set the initial temperature for dynamics runs
- `run` -- run the dynamics
"""

import ctypes

import pandas

import pycharmm.lib as lib
import pycharmm.coor as coor
import pycharmm.psf as psf


# TODO:
# 1. change all functions to keyword style signatures
# 2. take care of comment formatting
# 3. take care of any pycharm errors


class OPTIONS(ctypes.Structure):
    """A ctypes struct to hold runtime dynamics settings

    Attributes:
        ieqfrq The step frequency for assigning or scaling velocities to
               FINALT temperature during the equilibration stage of the
               dynamics run.
        ntrfrq The step frequency for stopping the rotation and translation
               of the molecule during dynamics. This operation is done
               automatically after any heating.
        ichecw The option for checking to see if the average temperature
               of the system lies within the allotted temperature window
               (between FINALT+TWINDH and FINALT+TWINDL) every
               IEQFRQ steps.
               .eq. 0 - do not check
                        i.e. assign or scale velocities.
               .ne. 0 - check window
                        i.e. assign or scale velocities only if average
                        temperature lies outside the window.
    """
    _fields_ = [('ieqfrq', ctypes.c_int),
                ('ntrfrq', ctypes.c_int),
                ('ichecw', ctypes.c_int),
                ('tbath', ctypes.c_double),
                ('iasors', ctypes.c_int),
                ('iasvel', ctypes.c_int),
                ('iscale', ctypes.c_int),
                ('iscvel', ctypes.c_int),
                ('isvfrq', ctypes.c_int),
                ('iprfrq', ctypes.c_int),
                ('ihtfrq', ctypes.c_int)]


def use_lang():
    """use Langevin dynamics

    :return int: True if Langevin dynamics was already selected
    """
    old_lang = lib.charmm.dynamics_use_lang()
    old_lang = bool(old_lang)
    return old_lang


def use_start():
    """use starting velocities described by iasvel

    :return bool: True if start was already selected
    """
    old_start = lib.charmm.dynamics_use_start()
    old_start = bool(old_start)
    return old_start


def use_restart():
    """dynamics is restarted by reading restart file from iunrea

    :return bool: True if start was already selected
    """
    old_restart = lib.charmm.dynamics_use_restart()
    old_restart = bool(old_restart)
    return old_restart


def set_nprint(new_nprint):
    """change step freq for printing and storing energy data for dynamics runs

    :param int new_nprint: the new step frequency desired
    :return int: old step freq
    """
    new_nprint = ctypes.c_int(new_nprint)
    old_nprint = lib.charmm.dynamics_set_nprint(ctypes.byref(new_nprint))
    return old_nprint


def get_nprint():
    """return step freq for printing and storing energy data for dynamics runs

    :return int: the current step frequency
    """
    nprint = lib.charmm.dynamics_get_nprint()
    return int(nprint)


def set_nstep(new_nstep):
    """change the number of steps to be taken in each dynamics run

    changes the number of dynamics steps which is equal to
    the number of energy evaluations

    :param int new_nstep: the new number of dynamics steps desired
    :return int: the previous setting for the number of dynamics steps
    """
    new_nstep = ctypes.c_int(new_nstep)
    old_nstep = lib.charmm.dynamics_set_nstep(ctypes.byref(new_nstep))
    return old_nstep


def get_nstep():
    """return the number of steps to be taken in each dynamics run

    returns the number of dynamics steps which is equal to
    the number of energy evaluations

    :return int: the current number of steps to be taken
    """
    nstep = lib.charmm.dynamics_get_nstep()
    return int(nstep)


def set_inbfrq(new_inbfrq):
    """change the freq of regenerating the nonbonded list for dynamics runs

    the list is regenerated if the current step number
    modulo INBFRQ is zero and if INBFRQ is non-zero.
    Specifying zero prevents the non-bonded list from being
    regenerated at all.
    INBFRQ = -1 --> all lists are updated when necessary
    (heuristic test).

    :param int new_inbfrq: the new freq for nonbonded list regeneration
    :return int: the old inbfrq
    """
    new_inbfrq = ctypes.c_int(new_inbfrq)
    old_inbfrq = lib.charmm.dynamics_set_inbfrq(ctypes.byref(new_inbfrq))
    return old_inbfrq


def set_ihbfrq(new_ihbfrq):
    """change the freq of regenerating the hydrogen bond list

    analogous to set_inbfrq

    :param int new_ihbfrq: the new freq for hydrogen list regeneration
    :return int: the old inbfrq
    """
    new_ihbfrq = ctypes.c_int(new_ihbfrq)
    old_ihbfrq = lib.charmm.dynamics_set_ihbfrq(ctypes.byref(new_ihbfrq))
    return old_ihbfrq


def set_ilbfrq(new_ilbfrq):
    """change the freq of checking whether an atom is in the Langevin region

    Langevin region defined by RBUF

    :param int new_ilbfrq: the new freq
    :return int: the old freq
    """
    new_ilbfrq = ctypes.c_int(new_ilbfrq)
    old_ilbfrq = lib.charmm.dynamics_set_ilbfrq(ctypes.byref(new_ilbfrq))
    return old_ilbfrq


def set_finalt(new_finalt):
    """set the final equilibrium temperature

    important for all stages except initiation
    the default is 298.0 Kelvin

    :param float new_finalt:
    :return float: old final temperature in Kelvin
    """
    new_finalt = ctypes.c_double(new_finalt)
    charmm_set_finalt = lib.charmm.dynamics_set_finalt
    charmm_set_finalt.restype = ctypes.c_double
    old_finalt = charmm_set_finalt(ctypes.byref(new_finalt))
    return old_finalt


def set_teminc(new_teminc):
    """set the temperature increment to be given to the system every IHTFRQ steps

    important for the heating stage
    the default is 5.0 Kelvin

    :param float new_teminc: the new temperature increment
    :return float: the old temperature increment
    """
    new_teminc = ctypes.c_double(new_teminc)
    charmm_set_teminc = lib.charmm.dynamics_set_teminc
    charmm_set_teminc.restype = ctypes.c_double
    old_teminc = charmm_set_teminc(ctypes.byref(new_teminc))
    return old_teminc


def set_tstruc(new_tstruc):
    """set the temperature at which the starting structure has been equilibrated

    used to assign velocities so that equal
    partition of energy will yield the correct equilibrated
    temperature
    -999.0 is a default which causes the
    program to assign velocities at T = 1.25 * FIRSTT

    :param float new_tstruc: the new temperature
    :return float: the old temperature
    """
    new_tstruc = ctypes.c_double(new_tstruc)
    charmm_set_tstruc = lib.charmm.dynamics_set_tstruc
    charmm_set_tstruc.restype = ctypes.c_double
    old_tstruc = charmm_set_tstruc(ctypes.byref(new_tstruc))
    return old_tstruc


def get_nrand():
    """return the number of integers required to seed the random number generator

    the random number generator plays a role in assigning velocities

    :return int: the current number of seed integers the random number generator needs
    """
    nrand = lib.charmm.dynamics_get_nrand()
    return int(nrand)


def set_rngseeds(new_seeds):
    """set seed for the random number generator

    The seed for the random number generator used for
    assigning velocities. If not specified a value based on
    the system clock is used; this is the recommended mode, since
    it makes each run unique.
    One integer, or as many as required by the random number
    generator, may be specified. See * note Hbonds: (doc/random.doc)

    :param list[int] new_seeds: new seeds for the random number generator
    :return bool: success == True
    """
    nrand = get_nrand()
    typed_seeds = (ctypes.c_int * nrand)(*new_seeds)
    success = lib.charmm.dynamics_set_rngseeds(typed_seeds)
    success = bool(success)
    return success


def set_iseed(new_seeds):
    """an alias for set_rngseeds"""
    return set_rngseeds(new_seeds)


def set_timest(new_timest):
    """set the time step in picoseconds for dynamics

    the default is 0.001 picoseconds

    :param float new_timest: the new time step in picoseconds
    :return float: old time step in picoseconds
    """
    new_timest = ctypes.c_double(new_timest)
    charmm_set_timest = lib.charmm.dynamics_set_timest
    charmm_set_timest.restype = ctypes.c_double
    old_timest = charmm_set_timest(ctypes.byref(new_timest))
    return old_timest


def set_akmast(new_akmast):
    """set the time step for dynamics in AKMA units

    :param float new_akmast: the new time step in AKMA units
    :return float: old time step in AKMA units
    """
    new_akmast = ctypes.c_double(new_akmast)
    charmm_set_akmast = lib.charmm.dynamics_set_akmast
    charmm_set_akmast.restype = ctypes.c_double
    old_akmast = charmm_set_akmast(ctypes.byref(new_akmast))
    return old_akmast


def set_firstt(new_firstt):
    """set the initial temperature for dynamics runs

    Set the initial temperature at which the velocities have to be
    assigned to begin the dynamics run. Important only
    for the initial stage of a dynamics run.

    :param float new_firstt: the initial temperature desired
    :return float: old initial temp
    """
    new_firstt = ctypes.c_double(new_firstt)
    charmm_set_firstt = lib.charmm.dynamics_set_firstt
    charmm_set_firstt.restype = ctypes.c_double
    old_firstt = charmm_set_firstt(ctypes.byref(new_firstt))
    return old_firstt


def set_twindh(new_twindh):
    """set the high temperature tolerance for equilibration

    :param float new_twindh: the new high temp tol for equilibration
    :return float: old high temp tol for equilibration
    """
    new_twindh = ctypes.c_double(new_twindh)
    charmm_set_twindh = lib.charmm.dynamics_set_twindh
    charmm_set_twindh.restype = ctypes.c_double
    old_twindh = charmm_set_twindh(ctypes.byref(new_twindh))
    return old_twindh


def set_twindl(new_twindl):
    """set the low temperature tolerance for equilibration

    :param float new_twindl: the new low temp tol for equilibration
    :return float: old low temp tol for equilibration
    """
    new_twindl = ctypes.c_double(new_twindl)
    charmm_set_twindl = lib.charmm.dynamics_set_twindl
    charmm_set_twindl.restype = ctypes.c_double
    old_twindl = charmm_set_twindl(ctypes.byref(new_twindl))
    return old_twindl


def set_echeck(new_echeck):
    """set the total energy change tol for each step

    :param float new_echeck: the new energy change tolerance
    :return float: old energy change tolerance
    """
    new_echeck = ctypes.c_double(new_echeck)
    charmm_set_echeck = lib.charmm.dynamics_set_echeck
    charmm_set_echeck.restype = ctypes.c_double
    old_echeck = charmm_set_echeck(ctypes.byref(new_echeck))
    return old_echeck


def set_nsavc(new_nsavc):
    """set the freq for saving coords to file

    :param int new_nsavc: the new frequency for saving coords to file
    :return int: the old frequency for saving coords to file
    """
    new_nsavc = ctypes.c_int(new_nsavc)
    old_nsavc = lib.charmm.dynamics_set_nsavc(ctypes.byref(new_nsavc))
    return old_nsavc


def set_nsavv(new_nsavv):
    """set the frequence for saving velocities to file

    :param int new_nsavv: the new frequency for seving velocities to file
    :return int: the old frequency for seving velocities to file
    """
    new_nsavv = ctypes.c_int(new_nsavv)
    old_nsavv = lib.charmm.dynamics_set_nsavv(ctypes.byref(new_nsavv))
    return old_nsavv


def set_fbetas(fbetas):
    """set friction coefs for atoms for Langevin dynamics

    :param list[float] fbetas: length natom, set atom i friction coeff to fbetas[i]
    :return list[float]: old friction coefs for the atoms
    """
    n = psf.get_natom()
    fbetas = (ctypes.c_double * n)(*fbetas)

    status = lib.charmm.dynamics_set_fbetas(fbetas)
    qstatus = bool(status)
    if not qstatus:
        raise RuntimeError('There was a problem setting fbetas.')

    return list(fbetas)


def set_iunwri(filename):
    """open a unit to use for the restart file

    :param string filename: new file path to write
    :return bool: true if successful
    """
    fn = ctypes.c_char_p(filename.encode())
    len_fn = ctypes.c_int(len(filename))

    status = lib.charmm.dynamics_set_iunwri(fn, ctypes.byref(len_fn))

    status = bool(status)
    return status


def set_iuncrd(filename):
    """open a unit to use for the restart file

    :param string filename: new file path to write
    :return bool: true if successful
    """
    fn = ctypes.c_char_p(filename.encode())
    len_fn = ctypes.c_int(len(filename))

    status = lib.charmm.dynamics_set_iuncrd(fn, ctypes.byref(len_fn))

    status = bool(status)
    return status


def set_iunrea(filename):
    """open a unit to read the restart file

    :param string filename: new file path to read
    :return bool: true if successful
    """
    fn = ctypes.c_char_p(filename.encode())
    len_fn = ctypes.c_int(len(filename))

    status = lib.charmm.dynamics_set_iunrea(fn, ctypes.byref(len_fn))

    status = bool(status)
    return status


def _configure(**kwargs):
    """set dynamics parameters from a dictionary of names and values

    :param kwargs: names and values from OPTIONS
    :return OPTIONS: a ctypes.Structure class for options that get set when
        dynamics runs, e.g. ieqfrq, ntrfrq and ichew
        this is to be passed into a call to the run function
    """
    valid_opts = dict(
        [('ieqfrq', 0),
         ('ntrfrq', 0),
         ('ichecw', 0),
         ('tbath', 298.0),
         ('iasors', 0),
         ('iasvel', 1),
         ('iscale', 0),
         ('iscvel', 0),
         ('isvfrq', 100),
         ('iprfrq', 100),
         ('ihtfrq', 0)])

    options = OPTIONS()
    for opt, default in valid_opts.items():
        setattr(options, opt, default)

    valid_toggles = dict(
        [('lang', use_lang),
         ('start', use_start),
         ('restart', use_restart)])

    valid_setters = dict([('nprint', set_nprint),
                          ('nstep',  set_nstep),
                          ('inbfrq', set_inbfrq),
                          ('ihbfrq', set_ihbfrq),
                          ('ilbfrq', set_ilbfrq),
                          ('finalt', set_finalt),
                          ('teminc', set_teminc),
                          ('tstruc', set_tstruc),
                          ('timest', set_timest),
                          ('akmast', set_akmast),
                          ('firstt', set_firstt),
                          ('twindh', set_twindh),
                          ('twindl', set_twindl),
                          ('echeck', set_echeck),
                          ('nsavc', set_nsavc),
                          ('nsavv', set_nsavv),
                          ('iseed', set_rngseeds),
                          ('fbeta', set_fbetas),
                          ('iunwri', set_iunwri),
                          ('iuncrd', set_iuncrd),
                          ('iunrea', set_iunrea)])

    for k, v in kwargs.items():
        if k in valid_opts:
            setattr(options, k, v)
        elif k in valid_toggles:
            toggle = valid_toggles[k]
            toggle()
        elif k in valid_setters:
            setter = valid_setters[k]
            setter(v)
        else:
            raise RuntimeError(k + ' is not a valid dynamics option')

    return options


def run(init_velocities=None, **kwargs):
    """execute a dynamics run for the current system

    :param dict init_velocities: initial velocity for each atom; 'vx', 'vy', and 'vz' each list[float]
    :param dict kwargs: names and values from OPTIONS (see _configure function)
    :return pandas.core.frame.DataFrame: a dataframe with index step number and columns named for the
             traditional dynamics energy output entry names
    """
    nstep = get_nstep()
    nprint = get_nprint()

    nrows = int(nstep / nprint) + 1
    ncols = 28
    nelts = nrows * ncols

    max_chars = 64

    vals = (ctypes.c_double * nelts)()

    labels_bufs = [ctypes.create_string_buffer(max_chars)
                   for _ in range(nelts)]
    labels_ptrs = (ctypes.c_char_p * nelts)(*map(ctypes.addressof,
                                                 labels_bufs))

    natom = coor.get_natom()
    if init_velocities:
        init_vx = (ctypes.c_double * natom)(*(init_velocities['vx'][0:natom]))
        init_vy = (ctypes.c_double * natom)(*(init_velocities['vy'][0:natom]))
        init_vz = (ctypes.c_double * natom)(*(init_velocities['vz'][0:natom]))

        out_vx = (ctypes.c_double * natom)()
        out_vy = (ctypes.c_double * natom)()
        out_vz = (ctypes.c_double * natom)()
    else:
        init_vx = None
        init_vy = None
        init_vz = None

        out_vx = None
        out_vy = None
        out_vz = None

    options = _configure(**kwargs)
    n_slots = lib.charmm.dynamics_run(ctypes.byref(ctypes.c_int(nrows)),
                                      ctypes.byref(ctypes.c_int(ncols)),
                                      labels_ptrs,
                                      vals,
                                      ctypes.byref(options),
                                      init_vx, init_vy, init_vz,
                                      out_vx, out_vy, out_vz)

    names = [label[:].decode(errors='ignore').strip('\x00')
             for label in labels_bufs]
    names = [names[i:i + ncols] for i in range(0, len(names), ncols)]
    names = [e[:n_slots] for e in names]

    vals = [vals[i:i + ncols] for i in range(0, len(vals), ncols)]
    vals = [e[:n_slots] for e in vals]

    indexes = [int(e[0]) for e in vals]
    names = [e[1:] for e in names]
    vals = [e[1:] for e in vals]

    if not init_velocities:
        out_vx = (ctypes.c_double * natom)()
        out_vy = (ctypes.c_double * natom)()
        out_vz = (ctypes.c_double * natom)()
        natom = lib.charmm.coor_get_comparison(out_vx, out_vy, out_vz)

    out_vx = [out_vx[i] for i in range(natom)]
    out_vy = [out_vy[i] for i in range(natom)]
    out_vz = [out_vz[i] for i in range(natom)]

    results = {'energy': pandas.DataFrame(vals,
                                          index=indexes,
                                          columns=names[0]),
               'velocities': pandas.DataFrame({'vx': out_vx,
                                               'vy': out_vy,
                                               'vz': out_vz})}

    return results
