# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""evaluation and manipulation of the potential energy of a macromolecular system

Functions
---------
- `show` -- print the energy table
- `get_total` -- return the current TOTE energy property
- `get_bonded` -- return the current energy term from bonded interactions
- `get_energy` -- run the main energy routine and return a pandas data frame
"""

import ctypes

import pandas

import pycharmm.lib as lib


# TODO:
# finish module docu
# consider a new way of getting table using the little get functions or just iterating over charmm's parallel e arrays


def show():
    """print the energy table
    """
    lib.charmm.print_energy()


def get_total():
    """return the current TOTE energy property

    :return float: the current TOTE
    """
    # Not sure why this is 3, but needed to change to 3 to get
    # total energy
    prop_index = ctypes.c_int(3)
    lib.charmm.get_energy_property.restype = ctypes.c_double
    tote = lib.charmm.get_energy_property(ctypes.byref(prop_index))
    return tote


def get_eprop(prop_index):
    """return the energy property from the eprop array at index prop_index

    :return float: eprop(prop_index)
    """
    prop_index = ctypes.c_int(prop_index)
    lib.charmm.get_energy_property.restype = ctypes.c_double
    prop = lib.charmm.get_energy_property(ctypes.byref(prop_index))
    return prop


def get_delta_e():
    """return the current Delta-E energy property

    :return float: the current energy delta (change in energy)
    """
    prop_index = ctypes.c_int(4)
    lib.charmm.get_energy_property.restype = ctypes.c_double
    delta_e = lib.charmm.get_energy_property(ctypes.byref(prop_index))
    return delta_e


def get_grms():
    """return the current GRMS energy property

    :return float: the current GRMS
    """
    prop_index = ctypes.c_int(5)
    lib.charmm.get_energy_property.restype = ctypes.c_double
    grms = lib.charmm.get_energy_property(ctypes.byref(prop_index))
    return grms


def get_eterm(term_index):
    """return the energy term at index term_index in the eterm array

    :return float: the current energy term from eterm(term_index)
    """
    term_index = ctypes.c_int(term_index)
    lib.charmm.get_energy_term.restype = ctypes.c_double
    term = lib.charmm.get_energy_term(ctypes.byref(term_index))
    return term


def get_bonded():
    """return the current energy term from bonded interactions

    :return float: the current energy term from bonded interactions
    """
    term_index = ctypes.c_int(1)
    lib.charmm.get_energy_term.restype = ctypes.c_double
    bond = lib.charmm.get_energy_term(ctypes.byref(term_index))
    return bond


def get_angle():
    """return the current energy term from bonded interactions

    :return float: the current energy term from bonded interactions
    """
    term_index = ctypes.c_int(2)
    lib.charmm.get_energy_term.restype = ctypes.c_double
    angle = lib.charmm.get_energy_term(ctypes.byref(term_index))
    return angle


def get_urey():
    """return the current energy term from bonded interactions

    :return float: the current energy term from bonded interactions
    """
    term_index = ctypes.c_int(3)
    lib.charmm.get_energy_term.restype = ctypes.c_double
    urey = lib.charmm.get_energy_term(ctypes.byref(term_index))
    return urey


def get_dihedral():
    """return the current energy term from bonded interactions

    :return float: the current energy term from bonded interactions
    """
    term_index = ctypes.c_int(4)
    lib.charmm.get_energy_term.restype = ctypes.c_double
    dihe = lib.charmm.get_energy_term(ctypes.byref(term_index))
    return dihe


def get_improper():
    """return the current energy term from bonded interactions

    :return float: the current energy term from bonded interactions
    """
    term_index = ctypes.c_int(5)
    lib.charmm.get_energy_term.restype = ctypes.c_double
    impr = lib.charmm.get_energy_term(ctypes.byref(term_index))
    return impr


def get_vdw():
    """return the current energy term from bonded interactions

    :return float: the current energy term from bonded interactions
    """
    term_index = ctypes.c_int(6)
    lib.charmm.get_energy_term.restype = ctypes.c_double
    vdw = lib.charmm.get_energy_term(ctypes.byref(term_index))
    return vdw


def get_elec():
    """return the current energy term from bonded interactions

    :return float: the current energy term from bonded interactions
    """
    term_index = ctypes.c_int(7)
    lib.charmm.get_energy_term.restype = ctypes.c_double
    elec = lib.charmm.get_energy_term(ctypes.byref(term_index))
    return elec


def get_energy():
    """run the main energy routine and return a pandas data frame

    :return pandas.core.frame.DataFrame: a dataframe with columns feature, name and value
    """
    vals = (ctypes.c_double * 28)()
    
    labels_bufs = [ctypes.create_string_buffer(64) for _ in range(28)]
    labels_ptrs = (ctypes.c_char_p * 28)(*map(ctypes.addressof, labels_bufs))
    
    n = lib.charmm.get_energy(labels_ptrs, vals)

    labels_str = [label.value.decode(errors='ignore') for label in labels_bufs[0:n]]
    labels = [label.strip() for label in labels_str]
    labels = [label for label in labels if label]

    vals = vals[0:n]

    feature_label_pairs = [label.split('_') for label in labels]
    feature_label_pairs = list(filter(lambda x: len(x) == 2, feature_label_pairs))

    n = min(len(vals), len(feature_label_pairs))
    
    features = list(map(lambda x: x[0], feature_label_pairs))
    names = list(map(lambda x: x[1].strip('\x00'), feature_label_pairs))

    energy_table = pandas.DataFrame({'feature': features[1:n],
                                     'name': names[1:n],
                                     'value': vals[1:n]})
    return energy_table
