# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""functions to construct and manipulate the PSF

The central data structure in CHARMM, the PSF holds lists giving every
bond, bond angle, torsion angle, and improper torsion angle
as well as information needed to generate the hydrogen bonds and
the non-bonded list.

Functions
---------
- `setup_seg` -- add the next segment to the PSF and name it <seg>
"""

import ctypes

import pycharmm.lib as lib
import pycharmm.script


_options = [('new_seg', ctypes.c_char * 9),
            ('dup_seg', ctypes.c_char * 9),
            ('patf', ctypes.c_char * 9),
            ('patl', ctypes.c_char * 9),
            ('ldrude', ctypes.c_int),
            ('lsetic', ctypes.c_int),
            ('lwarn', ctypes.c_int),
            ('lshow', ctypes.c_int),
            ('langle', ctypes.c_int),
            ('lphi', ctypes.c_int),
            ('dmass', ctypes.c_double)]


class OPTIONS(ctypes.Structure):
    """A ctypes structure to hold settings to generate a new segment.

    Attributes are listed by name, type, charmm input script equivalent,
    default value and a short description.

    Attributes:
      new_segid string name of the new segment
      dup_seg string DUPL name of segment to clone
      patf string FIRS DEFA patch residue name for terminating residue
      patl string LAST DEFA patch residue name for terminating residue
      ldrude integer DRUD 0 create drude particles?
      lsetic integer SETU 0 append ic table from topo file to main ic table?
      lwarn integer WARN 0 list elts deleted due to nonexistant atoms?
      lshow integer SHOW 0
      langle integer ANGL/NOAN autot overide autogen option from topo file?
      lphi integer DIHE/NODI autod overide autogen option from topo file?
      dmass real DMAS 0.0
    """
    _fields_ = _options


def new_segment(seg_name='', first_patch='', last_patch='', **kwargs):
    """add the next segment to the PSF and name it <seg>

    This function will cause any internal coordinate table entries
    (IC) from the topology file to be appended to the main IC table.
    This function uses the sequence of residues specified in the last
    input_sequence function and the information stored in the residue
    topology file to add the next segment to the PSF.

    Each segment contains a list of all the bonds, angles,
    dihedral angles, and improper torsions needed to calculate the energy.
    It also assigns charges to all the atoms, sets up the
    nonbonded exclusions list, and specifies hydrogen bond donors and
    acceptors. Any internal coordinate which references atoms outside
    the range of the segment is deleted. This prevents any
    unexpected bonding of segments.

    Parameters
    ----------
    seg_name : str
               name for the new segment
    first_patch : str
    last_patch : str

    Returns
    -------
    err_code : int
               one indicates success, any other value indicates failure
    """
    seg_name = seg_name.ljust(9)
    first_patch = first_patch.ljust(9)
    last_patch = last_patch.ljust(9)

    opts = OPTIONS(''.encode(), ''.encode(),
                   ''.encode(), ''.encode(),
                   0, 0, 0, 0, 0, 0,
                   0.0)

    # valid_opts = ['setup_ic', 'angle', 'dihedral', 'drude',
    #               'warn', 'show', 'mass']

    autot = lib.charmm.generate_get_autot()
    autod = lib.charmm.generate_get_autod()

    opts.new_seg = seg_name.encode()
    opts.dup_seg = '         '.encode()
    opts.patf = first_patch.encode()
    opts.patl = last_patch.encode()

    opts.langle = autot
    opts.lphi = autod

    types = dict(_options)
    for k, v in kwargs.items():
        if k == 'setup_ic':
            opts.lsetic = types['lsetic'](v)
        elif k == 'angle':
            opts.langle = types['langle'](v)
        elif k == 'dihedral':
            opts.lphi = types['lphi'](v)
        elif k == 'drude':
            opts.ldrude = types['ldrude'](v)
        elif k == 'warn':
            opts.lwarn = types['lwarn'](v)
        elif k == 'show':
            opts.lshow = types['lshow'](v)
        elif k == 'mass':
            opts.dmass = types['dmass'](v)

    err_code = lib.charmm.generate_segment(ctypes.byref(opts))
    return err_code


def setup_seg(seg):
    """add the next segment to the PSF and name it <seg>

    This function will cause any internal coordinate table entries
    (IC) from the topology file to be appended to the main IC table.
    This function uses the sequence of residues specified in the last
    input_sequence function and the information stored in the residue
    topology file to add the next segment to the PSF. Each segment contains a
    list of all the bonds, angles, dihedral angles, and improper torsions
    needed to calculate the energy. It also assigns charges to all the
    atoms, sets up the nonbonded exclusions list, and specifies hydrogen
    bond donors and acceptors. Any internal coordinate which references
    atoms outside the range of the segment is deleted. This prevents any
    unexpected bonding of segments.

    Parameters
    ----------
    seg : str
          name for the new segment

    Returns
    -------
    err_code : int
               one indicates success, any other value indicates failure
    """
    seg_len = len(seg)
    seg_str = ctypes.create_string_buffer(seg.encode())
    err_code = lib.charmm.generate_setup(seg_str,
                                         ctypes.byref(ctypes.c_int(seg_len)))
    return err_code

def patch(name,patch_sites, **kwargs):
    """patch a segment in the PSF with <patch_name>

    This function applies patches to the seqence 

    Parameters
    ----------
    name        : str
                  name for the patch to apply
    patch_sites : str 
                  comma separated string of pairs
                  segid1 resid1 [, segid2 resid2 [, ... [,segid 9 resid 9]...]
    **kwargs    : [sort=bool] [awtup=bool] [warn=bool]
                    
    Returns
    -------
    status : bool
             True indicates success
    """

    patch_command = 'patch '+str(name)
    patch_command += ' '+str(patch_sites)
    patch_script = pycharmm.script.CommandScript(patch_command, **kwargs)
    patch_script.run()
