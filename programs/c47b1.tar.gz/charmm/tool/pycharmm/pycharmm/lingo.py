# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""functions to parse other languages relevant to charmm

Functions
---------
- `charmm_script` -- evaluate a line of native charmm script
"""

import ctypes

import pycharmm.lib as lib


def _charmm_script_line(script):
    """evaluate a line of native charmm script

    Returns
    -------
    status : integer
             1 indicates success
    """
    c_script = ctypes.create_string_buffer(script.upper().encode())
    len_script = ctypes.c_int(len(script))

    status = lib.charmm.eval_charmm_script(c_script,
                                           ctypes.byref(len_script))
    return status


def _clean_charmm_script(script_lines):
    """remove comment lines, remove blank lines and join lines ending in -

    Returns
    -------
    reduction : list
                a list of non-blank non-comment lines that do not end in -
    """
    clean_lines = list()
    script_lines = [line.strip() for line in script_lines if line.strip()]
    script_lines = [line for line in script_lines if not line.startswith('!')]
    iter_lines = iter(script_lines)
    for sline in iter_lines:
        to_join = list()
        to_join.append(sline)
        while sline.endswith('-'):
            sline = next(iter_lines)
            to_join.append(sline)

        to_join = [line.rstrip('- ').strip() for line in to_join
                   if line.rstrip('- ').strip()]
        to_join = ' '.join(to_join)
        clean_lines.append(to_join)

    return clean_lines


# def charmm_script(script):
#     """evaluate one or several lines of native charmm script

#     Returns
#     -------
#     success : boolean
#               True indicates success
#     """
#     success = True
#     script_lines = _clean_charmm_script(script.splitlines())
#     for script_line in script_lines:
#         line_success = _charmm_script_line(script_line)
#         success = success and (1 == line_success)

#     return success


def charmm_script(script):
    """evaluate one or several lines of native charmm script

    Returns
    -------
    success : boolean
              True indicates success
    """
    c_script = ctypes.create_string_buffer(script.encode())
    len_script = ctypes.c_int(len(script))
    status = lib.charmm.eval_charmm_script(c_script, len_script)
    return status


class FoundValue(ctypes.Structure):
    _fields_ = [('is_found', ctypes.c_int),
                ('int_val', ctypes.c_int),
                ('bool_val', ctypes.c_int),
                ('real_val', ctypes.c_double)]


(NotFound, FoundInt, FoundReal, FoundBool) = (0, 1, 2, 3)
(BoolFalse, BoolTrue) = (0, 1)


def get_energy_value(name):
    """get the value of name in charmm

    Returns
    -------
    ret_val : None or numeric or boolean
              if name found, then value in charmm, otherwise None
    """
    c_name = ctypes.create_string_buffer(name.encode())
    n = ctypes.c_int(len(name))
    get_energy_val = lib.charmm.eval_get_energy_value
    get_energy_val.restype = FoundValue
    val = get_energy_val(c_name, n)

    if val.is_found == FoundInt:
        ret_val = int(val.int_val)
    elif val.is_found == FoundReal:
        ret_val = float(val.real_val)
    elif val.is_found == FoundBool:
        ret_val = False
        if val.bool_val == BoolTrue:
            ret_val = True
    else:  # consider throwing an error here
        ret_val = None

    return ret_val


def get_charmm_variable(name):
    """get the value of name in charmm

    Returns
    -------
    ret_val : string or None
              if name found, then value in charmm, otherwise None
    """
    len_name = ctypes.c_int(len(name))
    c_name = ctypes.create_string_buffer(name.encode())

    len_val = ctypes.c_int(128)
    c_val = ctypes.create_string_buffer(128)

    is_found = lib.charmm.eval_get_param(c_name, len_name, c_val, len_val)

    ret_val = None
    if is_found == BoolTrue:
        try:
            ret_val = int(c_val.value)
        except ValueError:
            try:
                ret_val = float(c_val.value)
            except ValueError:
                ret_val = c_val.value

    return ret_val


def set_charmm_variable(name, val):
    """set the value of name in charmm

    Returns
    -------
    ret_val : string or None
              if name found, then value in charmm, otherwise None
    """
    len_name = ctypes.c_int(len(name))
    c_name = ctypes.create_string_buffer(name.encode())

    val = str(val)
    len_val = ctypes.c_int(len(val))
    c_val = ctypes.create_string_buffer(val.encode())

    is_found = lib.charmm.eval_set_param(c_name, len_name, c_val, len_val)

    ret_val = False
    if is_found == BoolTrue:
        ret_val = True

    return ret_val
