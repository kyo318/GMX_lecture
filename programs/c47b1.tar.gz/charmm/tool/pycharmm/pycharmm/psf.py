# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""get data from charmm associated with 'psf' files

Functions
---------
- `get_natom` -- get the current total number of atoms from charmm
- `get_nres` -- get the current total number of residues from charmm
- `get_nseg` -- get the current total number of segments from charmm
- `get_ngrp` -- get the current total number of groups from charmm
- `get_iac` -- export a copy of iac (param type codes)
- `get_amass` -- export a copy of amass (atom masses)
- `get_charges` -- export a copy of cg (atom charges)
- `get_ibase` -- export a copy of ibase (last atom of each residue)
- `get_atype` -- export a copy of atype (atom name array)
- `get_res` -- export a copy of res (residue name array)
- `get_resid` -- export a copy of resid (residue identifier array)
- `get_segid` -- export a copy of segid (segment identifier array)
- `get_nictot` -- export a copy of nictot (nres for each seg)
- `get_igpbs` -- export a copy of igpbs (pointer for 1st atom in each group)
- `get_igptyp` -- export a copy of gptyp (code type of each group)
"""

import ctypes

import pycharmm
import pycharmm.lib as lib


def get_natom():
    """get the current total number of atoms from charmm

    Returns
    -------
    n : integer
        current total number of atoms
    """
    n = lib.charmm.psf_get_natom()
    return n


def get_nres():
    """get the current total number of residues from charmm

    Returns
    -------
    n : integer
        current total number of residues
    """
    n = lib.charmm.psf_get_nres()
    return n


def get_nseg():
    """get the current total number of residues from charmm

    Returns
    -------
    n : integer
        current total number of residues
    """
    n = lib.charmm.psf_get_nseg()
    return n


def get_ngrp():
    """get the current total number of groups from charmm

    Returns
    -------
    n : integer
        current total number of groups
    """
    n = lib.charmm.psf_get_ngrp()
    return n


def get_iac():
    """get an array of the param type code for each atom

    Returns
    -------
    iac : integer list
          param type code for each atom
    """
    n = get_natom()
    iac = (ctypes.c_int * n)(0)
    lib.charmm.psf_get_iac(iac)
    iac = [i - 1 for i in iac]
    return iac


def get_amass():
    """get an array of the mass of each atom

    Returns
    -------
    amass : double list
            mass of each atom
    """
    n = get_natom()
    amass = (ctypes.c_double * n)(0)
    lib.charmm.psf_get_amass(amass)
    return list(amass)


def get_charges():
    """get an array of each atoms charge

    Returns
    -------
    charges : double list
              charge of each atom
    """
    n = get_natom()
    charges = (ctypes.c_double * n)(0)
    lib.charmm.psf_get_charges(charges)
    return list(charges)


def get_ibase():
    """get array of last atom index of each residue

    Returns
    -------
    ibase : integer list
            last atom index of each residue
    """
    n = get_nres()
    ibase = (ctypes.c_int * (n + 1))(0)
    lib.charmm.psf_get_ibase(ibase)
    return ibase


def get_atype():
    """get list of IUPAC atom names

    Returns
    -------
    atype : string list
            IUPAC name for each atom
    """
    n = get_natom()
    atype_buffers = [ctypes.create_string_buffer(8) for _ in range(n)]
    atype_pointers = (ctypes.c_char_p * n)(*map(ctypes.addressof,
                                                atype_buffers))

    lib.charmm.psf_get_atype(atype_pointers)
    atype = [b.value.decode(errors='ignore') for b in atype_buffers[0:n]]
    return atype


def get_res():
    """get list of residue names

    Returns
    -------
    res : string list
          name for each residue
    """
    n = get_nres()
    res_buffers = [ctypes.create_string_buffer(8) for _ in range(n)]
    res_pointers = (ctypes.c_char_p * n)(*map(ctypes.addressof, res_buffers))

    lib.charmm.psf_get_res(res_pointers)
    # res = [b[:].decode().strip() for b in res_buffers[0:n]]
    res = [b.value.decode(errors='ignore') for b in res_buffers]
    return res


def get_res_idx(res_name):
    """get the index of the first residue with name res_name

    Parameters
    ----------
    res_name : string
               name to look for in res list

    Returns
    -------
    i : integer
        if res_name found, index of residue in res
        if res_name not found, 0
    """
    res_names = get_res()
    try:
        i = res_names.index(res_name)
    except ValueError:
        i = 0

    return i


def get_resid():
    """get list of residue idents

    Returns
    -------
    resid : string list
           identifier for each residue
    """
    n = get_nres()
    resid_buffers = [ctypes.create_string_buffer(8) for _ in range(n)]
    resid_pointers = (ctypes.c_char_p * n)(*map(ctypes.addressof,
                                                resid_buffers))

    lib.charmm.psf_get_resid(resid_pointers)
    resid = [b.value.decode(errors='ignore') for b in resid_buffers]
    return resid


def get_segid():
    """get list of segment idents

    Returns
    -------
    segid : string list
           identifier for each segment
    """
    n = get_nseg()
    segid_buffers = [ctypes.create_string_buffer(8) for _ in range(n)]
    segid_pointers = (ctypes.c_char_p * n)(*map(ctypes.addressof,
                                                segid_buffers))

    lib.charmm.psf_get_segid(segid_pointers)
    segid = [b.value.decode(errors='ignore') for b in segid_buffers[0:n]]
    return segid


def get_nictot():
    """get number of residues for each segment

    Returns
    -------
    nictot : integer list
             number of residues for each segment
    """
    n = get_nseg()
    nictot = (ctypes.c_int * (n + 1))(0)
    lib.charmm.psf_get_nictot(nictot)
    return nictot


def get_igpbs():
    """get first atom in each group

    Returns
    -------
    igpbs : integer list
            first atom in each group
    """
    n = get_ngrp()
    igpbs = (ctypes.c_int * (n + 1))(0)
    lib.charmm.psf_get_igpbs(igpbs)
    return igpbs


def get_igptyp():
    """get code type of each group

    Returns
    -------
    igptyp : integer list
             code type of each group
    """
    n = get_ngrp()
    igptyp = (ctypes.c_int * n)(0)
    lib.charmm.psf_get_igptyp(igptyp)
    return igptyp


def delete_atoms(selection=None, psort=False):
    """delete a selection of atoms from the psf

    Parameters
    ----------
    selection : pycharmm.SelectAtoms
                selection[i] == True <=> atom i is selected
    psort : boolean
            True <=> sort psf after deleted atoms are mapped out

    Returns
    -------
    status : bool
             true if successful
    """
    if not selection:
        selection = pycharmm.SelectAtoms().all_atoms()

    sel_c = selection.as_ctypes()
    isort = ctypes.c_int(psort)

    status = lib.charmm.psf_delete_atoms(sel_c, ctypes.byref(isort))

    status = bool(status)
    return status


def delete_bonds(iselect, jselect, psort=False):
    """delete bonds from the psf

    if atom i and atom j have a bond and
    iselect(i) is 1 and jselect(j) is 1
    then the bond is deleted

    Parameters
    ----------
    iselect : pycharmm.SelectAtoms
    jselect : pycharmm.SelectAtoms
    psort : boolean
            True <=> sort psf after deleted atoms are mapped out

    Returns
    -------
    status : bool
             true if successful
    """
    isel_c = iselect.as_ctypes()
    jsel_c = jselect.as_ctypes()
    isort = ctypes.c_int(psort)

    status = lib.charmm.psf_delete_bonds(isel_c, jsel_c, ctypes.byref(isort))

    status = bool(status)
    return status


def delete_angles(iselect, jselect, psort=False):
    """delete angles from the psf

    Parameters
    ----------
    iselect : pycharmm.SelectAtoms
    jselect : pycharmm.SelectAtoms
    psort : boolean
            True <=> sort psf after deleted atoms are mapped out

    Returns
    -------
    status : bool
             true if successful
    """
    isel_c = iselect.as_ctypes()
    jsel_c = jselect.as_ctypes()
    isort = ctypes.c_int(psort)

    status = lib.charmm.psf_delete_angles(isel_c, jsel_c, ctypes.byref(isort))

    status = bool(status)
    return status


def delete_dihedrals(iselect, jselect, psort=False):
    """delete dihedrals from the psf

    Parameters
    ----------
    iselect : pycharmm.SelectAtoms
    jselect : pycharmm.SelectAtoms
    psort : boolean
            True <=> sort psf after deleted atoms are mapped out

    Returns
    -------
    status : bool
             true if successful
    """
    isel_c = iselect.as_ctypes()
    jsel_c = jselect.as_ctypes()
    isort = ctypes.c_int(psort)

    status = lib.charmm.psf_delete_dihedrals(isel_c, jsel_c,
                                             ctypes.byref(isort))

    status = bool(status)
    return status


def delete_impropers(iselect, jselect, psort=False):
    """delete impropers from the psf

    Parameters
    ----------
    iselect : pycharmm.SelectAtoms
    jselect : pycharmm.SelectAtoms
    psort : boolean
            True <=> sort psf after deleted atoms are mapped out

    Returns
    -------
    status : bool
             true if successful
    """
    isel_c = iselect.as_ctypes()
    jsel_c = jselect.as_ctypes()
    isort = ctypes.c_int(psort)

    status = lib.charmm.psf_delete_impropers(isel_c, jsel_c,
                                             ctypes.byref(isort))

    status = bool(status)
    return status


def delete_cmaps(iselect, jselect, psort=False):
    """delete cmaps from the psf

    Parameters
    ----------
    iselect : pycharmm.SelectAtoms
    jselect : pycharmm.SelectAtoms
    psort : boolean
            True <=> sort psf after deleted atoms are mapped out

    Returns
    -------
    status : bool
             true if successful
    """
    isel_c = iselect.as_ctypes()
    jsel_c = jselect.as_ctypes()
    isort = ctypes.c_int(psort)

    status = lib.charmm.psf_delete_cmaps(isel_c, jsel_c, ctypes.byref(isort))

    status = bool(status)
    return status


def delete_connectivity(iselect, jselect, psort=False):
    """delete all connectivity between selected atoms from the psf

    includes bonds, angles, dihedrals, impropers, and cmaps

    Parameters
    ----------
    iselect : pycharmm.SelectAtoms
    jselect : pycharmm.SelectAtoms
    psort : boolean
            True <=> sort psf after deleted atoms are mapped out

    Returns
    -------
    status : bool
             true if successful
    """
    isel_c = iselect.as_ctypes()
    jsel_c = jselect.as_ctypes()
    isort = ctypes.c_int(psort)

    status = lib.charmm.psf_delete_conn(isel_c, jsel_c, ctypes.byref(isort))

    status = bool(status)
    return status
