# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""Select and manipulate sets of atoms

Types
---------
- `Selection` -- a selection of atoms to manipulate

Functions
---------
- `or_selection` -- use eltwise logical or to produce a new selection
- `and_selection` -- use eltwise logical and to produce a new selection
- `not_selection` -- use eltwise logical not to produce a new selection
- `none_selection` -- get a new selection in which all elements are False
- `all_selection` -- get a new selection in which all elements are True
- `by_atom_inds` -- copy selection to new_sel then set new_sel[inds] to True
- `by_residue_name` -- select all atoms in a residue
- `by_residue_id` -- select all atoms in a residue by residue id
- `by_segment_id` -- select all atoms in a segment
- `by_atom_type` -- select all atoms of type atype
- `by_chem_type` -- select all atoms of param type code chem_type
- `all_atoms` -- select all atoms
- `no_atoms` -- select no atoms
- `by_residue_atom` -- select all atoms in single residue with IUPAC name atype
- `by_point` -- selects all atoms within a sphere around point (x,y,z) with radius cut
- `is_hydrogen` -- true if atom i is hydrogen
- `is_lone` -- true if atom i is lonepair
- `is_initial` -- true if atom i has known coords
- `hydrogen` -- selects all hydrogen atoms
- `initial` -- selects all atoms with known coords
- `lone` -- selects all lonepair atoms
- `get_property` -- return array filled with natoms numeric property prop
- `prop` -- select all atoms for which func(tol, prop_val) is True
- `residues` -- select all atoms in a range of residues
- `segments` -- select all atoms in a range of segments
- `whole_residues` -- select the whole residue of each atom in a selection
- `around` -- select all atoms within r_cut of the current selection
- `get_max_name` -- ask charmm for the max len of the name of a stored selection
- `get_num_stored` -- ask charmm for the number of stored selections
- `find` -- get the index of the named stored selection
- `store_selection` -- store selection in charmm as name
- `get_stored_names` -- get a list of all names of selections stored in charmm
- `delete_stored_selection` -- remove the named selection from charmm
"""


import ctypes
import math
import typing
from collections.abc import Iterable

import numpy as np

import pycharmm
import pycharmm.coor as coor
import pycharmm.lib as lib
import pycharmm.param as param
import pycharmm.psf as psf

import pycharmm.atom_info as atom_info


Selection = typing.Tuple[bool]


def or_selection(sel_a: Selection, sel_b: Selection) -> Selection:
    return tuple(elt_a or elt_b for elt_a, elt_b in zip(sel_a, sel_b))


def and_selection(sel_a: Selection, sel_b: Selection) -> Selection:
    return tuple(elt_a and elt_b for elt_a, elt_b in zip(sel_a, sel_b))


def not_selection(sel: Selection) -> Selection:
    return tuple(not elt for elt in sel)


def none_selection(size: int) -> Selection:
    return (False, ) * size


def all_selection(size: int) -> Selection:
    return (True, ) * size


def by_atom_inds(inds: Iterable, selection: Selection) -> Selection:
    new_sel = tuple(True if i in inds else val
                    for i, val in enumerate(selection))
    return new_sel


def by_residue_name(residue_name: str) -> Selection:
    """select all atoms in a residue

    Parameters
    ----------
    residue_name : string
                   name of residue to select

    Returns
    -------
    flags : boolean list
            atom i selected <==> flags[i] == True
    """
    res = psf.get_res()
    ibase = psf.get_ibase()
    select_inds = tuple()
    for i, name in enumerate(res):
        if name == residue_name:
            for j in range(ibase[i], ibase[i + 1]):
                select_inds = select_inds + (j, )

    n_atoms = psf.get_natom()
    return by_atom_inds(select_inds, none_selection(n_atoms))


def by_residue_id(residue_id: str) -> Selection:
    """select all atoms in a residue by residue id

    Parameters
    ----------
    residue_id : string
                 charmm id of residue to select

    Returns
    -------
    flags : Selection
            atom i selected <==> flags[i] == True
    """
    ids = psf.get_resid()
    ibase = psf.get_ibase()
    select_inds = tuple()
    for i, name in enumerate(ids):
        if name == residue_id:
            for j in range(ibase[i], ibase[i + 1]):
                select_inds = select_inds + (j, )

    n_atoms = psf.get_natom()
    return by_atom_inds(select_inds, none_selection(n_atoms))


def by_segment_id(segment_id: str) -> Selection:
    """select all atoms in a segment

    Parameters
    ----------
    segment_id : string
                 name of segment to select

    Returns
    -------
    flags : Selection
            atom i selected <==> flags[i] == True
    """
    segids = psf.get_segid()
    ibase = psf.get_ibase()
    nictot = psf.get_nictot()
    select_inds = tuple()
    for i, name in enumerate(segids):
        if name == segment_id:
            for j in range(nictot[i], nictot[i + 1]):
                for k in range(ibase[j], ibase[j + 1]):
                    select_inds = select_inds + (k, )

    n_atoms = psf.get_natom()
    return by_atom_inds(select_inds, none_selection(n_atoms))


def by_atom_type(atom_type: str) -> Selection:
    """select all atoms of type atype

    Parameters
    ----------
    atom_type : string
                IUPAC name of type to select

    Returns
    -------
    flags : boolean list
            atom i selected <==> flags[i] == True
    """
    atom_types = psf.get_atype()
    select_inds = tuple()
    for i, current_type in enumerate(atom_types):
        if atom_type == current_type:
            select_inds = select_inds + (i, )

    n_atoms = psf.get_natom()
    return by_atom_inds(select_inds, none_selection(n_atoms))


def by_chem_type(chem_type: str) -> Selection:
    """select all atoms of param type code chem_type

    Parameters
    ----------
    chem_type : string
                parameter type code to select

    Returns
    -------
    flags : boolean list
            atom i selected <==> flags[i] == True
    """
    natc = param.get_natc()
    atc = param.get_atc()
    iac = psf.get_iac()
    select_inds = tuple()
    n_atoms = psf.get_natom()
    for i in range(n_atoms):
        if iac[i] > natc:
            raise ValueError('No VDW parameters available for CHEM token '
                             + chem_type)

        if chem_type == atc[iac[i]]:
            select_inds = select_inds + (i, )

    return by_atom_inds(select_inds, none_selection(n_atoms))


def all_atoms() -> Selection:
    """select all atoms

    Returns
    -------
    flags : Selection
            atom i selected <==> flags[i] == True
    """
    n_atoms = psf.get_natom()
    return all_selection(n_atoms)


def no_atoms() -> Selection:
    """select no atoms

    Returns
    -------
    flags : Selection
            atom i selected <==> flags[i] == True
    """
    n_atoms = psf.get_natom()
    return none_selection(n_atoms)


def by_residue_atom(segid: str, resid: str, atype: str) -> Selection:
    """select all atoms in single residue with IUPAC name atype

    Parameters
    ----------
    segid : string
            segment identifier (A1, MAIN, ...)
    resid : string
            residue identifier (1, 23, 45B, ...)
    atype : string
            an IUPAC name

    Returns
    -------
    flags : Selection
            atom i selected <==> flags[i] == True
    """
    segids = psf.get_segid()
    resids = psf.get_resid()
    atypes = psf.get_atype()
    ibase = psf.get_ibase()
    nictot = psf.get_nictot()
    select_inds = tuple()
    for seg_i, name in enumerate(segids):
        if segid == name:
            for res_i in range(nictot[seg_i], nictot[seg_i + 1]):
                if resid == resids[res_i]:
                    for atom_i in range(ibase[res_i], ibase[res_i + 1]):
                        if atype == atypes[atom_i]:
                            select_inds = select_inds + (atom_i, )

    n_atoms = psf.get_natom()
    return by_atom_inds(select_inds, none_selection(n_atoms))


def by_point(x: float, y: float, z: float,
             cut=8.0, periodic=False) -> Selection:
    """selects all atoms within a sphere around point (x,y,z) with radius cut

    Parameters
    ----------
    x : real
        x coord of selection sphere center
    y : real
        y coord of selection sphere center
    z : real
        z coord of selection sphere center
    cut : real
          radius of selection sphere
    periodic : boolean
               if simple periodic boundary conditions are in effect
               through the use of the MIPB command,
               the selection reflects the appropriate periodic boundaries

    Returns
    -------
    flags : Selection
            atom i selected <==> flags[i] == True
    """
    n_atoms = psf.get_natom()
    select_inds = tuple()
    positions = coor.get_positions()
    for i in range(n_atoms):
        pos_i = positions.iloc[i]
        dx = x - pos_i['x']
        dy = y - pos_i['y']
        dz = z - pos_i['z']

        if periodic:
            is_to_box = lib.charmm.pbound_is_to_box()
            is_cubic_box = lib.charmm.pbound_is_cubic_box()
            if is_to_box.value == 1 or is_cubic_box.value == 1:
                boxinv_x = ctypes.c_double(0.0)
                boxinv_y = ctypes.c_double(0.0)
                boxinv_z = ctypes.c_double(0.0)
                lib.charmm.pbound_get_boxinv(ctypes.byref(boxinv_x),
                                             ctypes.byref(boxinv_y),
                                             ctypes.byref(boxinv_z))
                dx *= boxinv_x
                if dx > 0.5:
                    dx -= 1.0

                if dx < -0.5:
                    dx += 1.0

                dy *= boxinv_y
                if dy > 0.5:
                    dy -= 1.0

                if dy < -0.5:
                    dy += 1.0

                dz *= boxinv_z
                if dz > 0.5:
                    dz -= 1.0

                if dz < -0.5:
                    dz += 1.0

                if is_to_box.value == 1:
                    lib.charmm.pbound_get_r75.restype = ctypes.c_double
                    r75 = lib.charmm.pbound_get_r75()
                    corr = 0.5 * math.trunc(r75 *
                                            (abs(dx) + abs(dy) + abs(dz)))
                    dx -= math.copysign(corr, dx)
                    dy -= math.copysign(corr, dy)
                    dz -= math.copysign(corr, dz)

                size_x = ctypes.c_double(0.0)
                size_y = ctypes.c_double(0.0)
                size_z = ctypes.c_double(0.0)
                lib.charmm.pbound_get_size(ctypes.byref(size_x),
                                           ctypes.byref(size_y),
                                           ctypes.byref(size_z))
                dx *= size_x
                dy *= size_y
                dz *= size_z
            else:
                dx = ctypes.c_double(dx)
                dy = ctypes.c_double(dy)
                dz = ctypes.c_double(dz)
                lib.charmm.pbound_pbmove(ctypes.byref(dx),
                                         ctypes.byref(dy),
                                         ctypes.byref(dz))

        dist_sq = dx * dx + dy * dy + dz * dz
        if dist_sq <= cut:
            select_inds = select_inds + (i, )

    return by_atom_inds(select_inds, none_selection(n_atoms))


def is_hydrogen(i: int) -> bool:
    """true if atom i is hydrogen

    Parameters
    ----------
    i : integer
        index of atom to test

    Returns
    -------
    answer : boolean
            atom i is hydrogen <==> answer == True
    """
    c_i = ctypes.c_int(i + 1)
    test = lib.charmm.select_is_hydrog(ctypes.byref(c_i))
    answer = False
    if test == 1:
        answer = True

    return answer


def is_lone(i: int) -> bool:
    """true if atom i is lonepair

    Parameters
    ----------
    i : integer
        index of atom to test

    Returns
    -------
    answer : boolean
            atom i is lonepair <==> answer == True
    """
    c_i = ctypes.c_int(i + 1)
    test = lib.charmm.select_is_lone(ctypes.byref(c_i))
    answer = False
    if test == 1:
        answer = True

    return answer


def is_initial(i: int) -> bool:
    """true if atom i has known coords

    Parameters
    ----------
    i : integer
        index of atom to test

    Returns
    -------
    answer : boolean
            atom i has known coords <==> answer == True
    """
    c_i = ctypes.c_int(i + 1)
    test = lib.charmm.select_is_initial(ctypes.byref(c_i))
    answer = False
    if test == 1:
        answer = True

    return answer


def hydrogen() -> Selection:
    """selects all hydrogen atoms

    Returns
    -------
    flags : boolean list
            atom i hydrogen <==> flags[i] == True
    """
    n_atoms = psf.get_natom()
    select_inds = tuple(i for i in range(n_atoms) if is_hydrogen(i))
    return by_atom_inds(select_inds, none_selection(n_atoms))


def initial() -> Selection:
    """selects all atoms with known coords

    Returns
    -------
    flags : boolean list
            atom i has known coords <==> flags[i] == True
    """
    n_atoms = psf.get_natom()
    select_inds = tuple(i for i in range(n_atoms) if is_initial(i))
    return by_atom_inds(select_inds, none_selection(n_atoms))


def lone() -> Selection:
    """selects all lonepair atoms

    Returns
    -------
    flags : boolean list
            atom i lonepair <==> flags[i] == True
    """
    n_atoms = psf.get_natom()
    select_inds = tuple(i for i in range(n_atoms) if is_lone(i))
    return by_atom_inds(select_inds, none_selection(n_atoms))


def get_property(prop_name):
    """return array filled with natoms numeric property prop

    Parameters
    ----------
    prop_name : string
                identifier for numeric property of atoms

    Returns
    -------
    prop_vals : numeric list
                numeric value for each atom i representing prop
    """
    c_prop = ctypes.c_char_p(prop_name.encode('utf-8').lower())
    n_atoms = psf.get_natom()
    prop_vals = (ctypes.c_double * n_atoms)(0.0)
    lib.charmm.select_get_property(c_prop, prop_vals,
                                   ctypes.c_int(n_atoms))
    prop_vals = list(prop_vals)
    return prop_vals


def prop(prop_name, func: typing.Callable[[float, float], bool], tol) -> Selection:
    """select all atoms for which func(tol, prop_val) is True

    Parameters
    ----------
    prop_name : string
                identifier for numeric property of atoms
    func : function
           of two arguments, func(tol, prop_val)
    tol : real
          tolerance to pass to func as first argument

    Returns
    -------
    flags : boolean list
            atom i selected <==> flags[i] == True
    """
    select_inds = tuple(i for i, p in enumerate(get_property(prop_name))
                        if func(tol, p))
    n_atoms = psf.get_natom()
    return by_atom_inds(select_inds, none_selection(n_atoms))


def residues(resname_a: str, resname_b='') -> Selection:
    """select all atoms in a range of residues

    Parameters
    ----------
    resname_a : string
                name of first residue in range
    resname_b : string
                name of last residue in range

    Returns
    -------
    flags : list of integers
            flags[i] == 1 means that atom i is selected
    """
    c_name_a = ctypes.c_char_p(resname_a.encode('utf-8'))
    if resname_b:
        c_name_b = ctypes.c_char_p(resname_b.encode('utf-8'))
    else:
        c_name_b = ctypes.c_char_p(resname_a.encode('utf-8'))

    natom = psf.get_natom()
    flags = (ctypes.c_int * natom)(0 * natom)
    lib.charmm.select_resname_range(c_name_a, c_name_b, flags)
    return tuple(True if flag == 1 else False for flag in flags)


def segments(segid_a: str, segid_b='') -> Selection:
    """select all atoms in a range of segments

    Parameters
    ----------
    segid_a : string
              name of first segment in range
    segid_b : string
              name of last segment in range

    Returns
    -------
    flags : list of integers
            flags[i] == 1 means that atom i is selected
    """
    c_name_a = ctypes.c_char_p(segid_a.encode('utf-8'))
    if segid_b:
        c_name_b = ctypes.c_char_p(segid_b.encode('utf-8'))
    else:
        c_name_b = ctypes.c_char_p(segid_a.encode('utf-8'))

    natom = psf.get_natom()
    flags = (ctypes.c_int * natom)(0 * natom)
    lib.charmm.select_segid_range(c_name_a, c_name_b, flags)
    return tuple(True if flag == 1 else False for flag in flags)


def whole_residues(sel: Selection) -> Selection:
    """select the whole residue of each atom in a selection

    :param sel: selection of atoms, each atom's whole residue will be selected
    :type sel: Selection
    :return: a new selection of residues
    :rtype: Selection
    """
    residue_table = atom_info.atom_to_res()
    residues_wanted = atom_info.get_res_indexes([i for i, v in enumerate(sel) if v])
    new_sel = none_selection(len(sel))
    new_indexes = [i for i, v in enumerate(residue_table) if v in residues_wanted]
    return by_atom_inds(new_indexes, new_sel)


def around(sel: Selection, r_cut: float) -> Selection:
    """select all atoms within r_cut of the current selection

    This is equivalent to CHARMM's ".around." command.
    Implemented as a linked-list cell algorithm.
    More information at: https://doi.org/10.1017/CBO9780511816581 and ISBN: 9780122673511

    :param sel: the current selection
    :type sel: Selection
    :param r_cut: Selection cut-off
    :type r_cut: float
    :raise: ValueError if r_cut is 0 angstroms or less
    :return: A new SelectAtoms object is returned. It contains the new selection.
             The new selection includes the current selection.
    :rtype: SelectAtoms

    :example:

    >>> # select all water molecules that are 2.8 angstroms from the protein
    >>> example_sel = pycharmm.SelectAtoms(segid="TIP3") & pycharmm.SelectAtoms(segid="PROTEIN").around(2.8)
    """
    if r_cut <= 0:
        raise ValueError("r_cut should be greater than 0 angstroms!")

    # get dimensions of entire system (not just selection)
    stats = coor.stat()
    lx = stats["xmax"] - stats["xmin"]
    ly = stats["ymax"] - stats["ymin"]
    lz = stats["zmax"] - stats["zmin"]
    system_length = max(lx, ly, lz)

    rn = system_length / int(system_length / r_cut)  # cell length
    sc = int(system_length / rn)  # number of cells along an axis

    # relative neighborhood array
    d_half = np.array([[0, 0, 0], [1, 0, 0], [1, 1, 0], [-1, 1, 0],
                       [0, 1, 0], [0, 0, 1], [-1, 0, 1], [1, 0, 1], [-1, -1, 1],
                       [0, -1, 1], [1, -1, 1], [-1, 1, 1], [0, 1, 1], [1, 1, 1]])
    d = np.unique(np.concatenate((d_half, -d_half)), axis=0)  # get all 27 neighbors including self cell (0,0,0)

    pos = coor.get_positions()
    r = pos.to_numpy()  # 3d array coordinates of our system
    pos_sel = pos[list(sel)]
    r_sel_indices = tuple(pos_sel.index)  # get the selected atom indices
    c = np.floor([[i[0] / rn, i[1] / rn, i[2] / rn] for i in r]).astype(
        np.int_)  # N*3 array of cell indices for all atoms (each atom assigned to a cell)
    natom = psf.get_natom()
    ll = [0] * natom
    head = np.full((sc, sc, sc), -1)
    near = list()  # atoms that are nearby

    # create our linked list and header list
    for i, icell in enumerate(c):
        # icell is index of cell, i is the atom index
        ll[i] = int(head[icell[0]][icell[1]][icell[2]])  # store
        head[icell[0]][icell[1]][icell[2]] = int(i)

    for i in r_sel_indices:  # loop through our selection
        icell = c[i]  # get cell that selected atom is in
        for dj in d:
            jcell = icell + dj
            # jcell = np.mod(jcell, sc)  # apply periodic conditions so that if jcell contains index > sc, it wraps back
            j = int(head[jcell[0]][jcell[1]][jcell[2]])
            while j >= 0:  # while the atom chain still continues
                dr = np.linalg.norm(r[i] - r[j])
                if dr <= r_cut:
                    near.append(j)

                j = ll[j]

    near = list(set(near))  # remove duplicates
    sel_near = [False] * natom  # convert list of atom indices to atom selection boolean list
    for i in near:
        sel_near[i] = True

    return tuple(sel_near)


def get_max_name() -> int:
    """ask charmm for the max len of the name of a stored selection
    """
    max_name = lib.charmm.select_get_max_name()
    return max_name


def get_num_stored() -> int:
    """ask charmm for the number of stored selections
    """
    num_stored = lib.charmm.select_get_num_stored()
    return num_stored


def find(name: str) -> int:
    """get the index of the named stored selection
    """
    c_name = ctypes.c_char_p(name.encode('utf-8'))
    c_len_name = ctypes.c_int(len(name))
    found = lib.charmm.select_find(c_name, c_len_name)
    return found


def store_selection(name: str, sel: Selection) -> str:
    """store selection in charmm as name
    """
    c_name = ctypes.c_char_p(name.upper().encode('utf-8'))
    c_len_name = ctypes.c_int(len(name))

    c_sel = (ctypes.c_int * len(sel))(*sel)
    c_len_sel = ctypes.c_int(len(sel))

    lib.charmm.select_store(c_name, c_len_name, c_sel, c_len_sel)
    print('A selection has been stored as {}'.format(name.upper()))
    return name


def get_stored_names() -> typing.List[str]:
    """get a list of all the names of the selections stored in charmm
    """
    n = get_num_stored()
    max_name = get_max_name()
    name_buffers = [ctypes.create_string_buffer(max_name) for _ in range(n)]
    name_pointers = (ctypes.c_char_p * n)(*map(ctypes.addressof,
                                               name_buffers))

    lib.charmm.select_get_stored_names(name_pointers, ctypes.c_int(n), ctypes.c_int(max_name))
    names = [b.value.decode(errors='ignore') for b in name_buffers[0:n]]
    return names


def delete_stored_selection(name: str) -> str:
    """remove the named selection from charmm
    """
    c_name = ctypes.c_char_p(name.encode('utf-8'))
    c_len_name = ctypes.c_int(len(name))
    lib.charmm.select_delete(c_name, c_len_name)
    return name
