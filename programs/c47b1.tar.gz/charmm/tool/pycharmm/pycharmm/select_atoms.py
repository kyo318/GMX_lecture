import ctypes
import random
import string
import typing

import pycharmm.psf as psf
import pycharmm.select as select
import pycharmm.atom_info as atom_info


def _get_random_string(str_size):
    return ''.join(random.choice(string.ascii_letters)
                   for _ in range(str_size)).upper()


def _generate_script_name():
    max_name = select.get_max_name()
    rand_name = _get_random_string(max_name)
    found = select.find(rand_name)
    iter_limit = 100
    while found > 0 and iter_limit > 0:
        rand_name = _get_random_string(max_name)
        found = select.find(rand_name)
        iter_limit -= 1

    if iter_limit <= 0 < found:
        raise RuntimeError('For this selection, ' +
                           'tried 100 random names, and ' +
                           'could not find an unused random name.')

    return rand_name


class SelectAtoms:
    def __init__(self, selection=None,
                 select_all=False,
                 seg_id='',
                 res_id='', res_name='',
                 atom_type='', chem_type='',
                 initials=False,
                 lonepairs=False,
                 hydrogens=False,
                 update=True):
        self._name = ''
        self._stored = False
        self._do_update = update
        self._selection = None
        n_atoms = psf.get_natom()
        if selection:
            self.set_selection(selection)
        else:
            self.set_selection(select.none_selection(n_atoms))

        if select_all:
            self.set_selection(select.all_selection(n_atoms))

        if seg_id:
            self.by_seg_id(seg_id)

        if res_id:
            self.by_res_id(res_id)

        if res_name:
            self.by_res_name(res_name)

        if atom_type:
            self.by_atom_type(atom_type)

        if chem_type:
            self.by_chem_type(chem_type)

        if initials:
            self.all_initial_atoms()

        if lonepairs:
            self.all_lonepair_atoms()

        if hydrogens:
            self.all_hydrogen_atoms()

    def _select_atom(self, atom_i):
        old_val = self[atom_i]
        self.set_selection(select.by_atom_inds(self.get_selection(), atom_i))
        return old_val

    def _deselect_atom(self, atom_i):
        old_val = self[atom_i]
        new_sel = tuple(sel if not ind == atom_i else False
                        for ind, sel in enumerate(self.get_selection()))
        self.set_selection(new_sel)
        return old_val

    def get_selection(self) -> select.Selection:
        return self._selection

    def set_selection(self, selection: select.Selection):
        self._selection = selection
        if self._do_update:
            self._update()
        else:
            print('WARNING: Atom properties for ' +
                  'this selections are not up to date.')

        return self

    def by_seg_id(self, seg_id):
        new_sel = select.or_selection(self.get_selection(),
                                      select.by_segment_id(seg_id))
        self.set_selection(new_sel)
        return self

    def by_res_id(self, res_id):
        new_sel = select.or_selection(self.get_selection(),
                                      select.by_residue_id(res_id))
        self.set_selection(new_sel)
        return self

    def by_res_name(self, res_name):
        new_sel = select.or_selection(self.get_selection(),
                                      select.by_residue_name(res_name))
        self.set_selection(new_sel)
        return self

    def by_chem_type(self, chem_type):
        new_sel = select.or_selection(self.get_selection(),
                                      select.by_chem_type(chem_type))
        self.set_selection(new_sel)
        return self

    def by_atom_type(self, atom_type):
        new_sel = select.or_selection(self.get_selection(),
                                      select.by_atom_type(atom_type))
        self.set_selection(new_sel)
        return self

    def in_sphere(self, x, y, z, radius=0.8, is_periodic=False):
        new_sel = select.or_selection(self.get_selection(),
                                      select.by_point(x, y, z,
                                                      radius,
                                                      is_periodic))
        self.set_selection(new_sel)
        return self

    def by_res_and_type(self, seg_id, res_id, atom_type):
        """select all atoms in single residue with IUPAC name atype

        Parameters
        ----------
        seg_id : string of
                 segment identifiers ('A1 MAIN SEG1 ... SEGn')
        res_id : string of
                 residue identifiers ('1 3 5 6 ...n')
        atom_type : string of
                    an IUPAC names ('C CA CB N S')

        Returns
        -------
        flags : boolean list
                atom i selected <==> flags[i] == True
        """
        seg = SelectAtoms()
        for segid in seg_id.strip().split():
            seg.by_seg_id(segid)
        res = SelectAtoms()
        for resid in res_id.strip().split():
            res.by_res_id(res_id=resid)
        atoms = SelectAtoms()
        for atomname in atom_type.strip().split():
            atoms.by_atom_type(atom_type=atomname)
        my_atom = seg & res & atoms
        new_sel = select.or_selection(self.get_selection(),
                                      my_atom.get_selection())
        self.set_selection(new_sel)
        return self

    def all_atoms(self):
        self.set_selection(select.all_atoms())
        return self

    def all_initial_atoms(self):
        new_sel = select.or_selection(self.get_selection(),
                                      select.initial())
        self.set_selection(new_sel)
        return self

    def all_lonepair_atoms(self):
        new_sel = select.or_selection(self.get_selection(),
                                      select.lone())
        self.set_selection(new_sel)
        return self

    def all_hydrogen_atoms(self):
        new_sel = select.or_selection(self.get_selection(),
                                      select.hydrogen())
        self.set_selection(new_sel)
        return self

    def by_property(self, prop_name: str,
                    func: typing.Callable[[float, float], bool],
                    tol: float):
        new_sel = select.or_selection(self.get_selection(),
                                      select.prop(prop_name,
                                                  func,
                                                  tol))
        self.set_selection(new_sel)
        return self

    def around(self, radius):
        new_sel = select.around(self.get_selection(), radius)
        self.set_selection(new_sel)
        return self

    def whole_residues(self):
        new_sel = select.whole_residues(self.get_selection())
        self.set_selection(new_sel)
        return self

    def __list__(self):
        return list(self.get_selection())

    def as_ctypes(self):
        atoms = [int(atom) for atom in list(self)]
        natoms = len(atoms)
        c_selection = (ctypes.c_int * natoms)(*atoms)
        return c_selection

    def __len__(self):
        return len(self.get_selection())

    def __and__(self, other):
        new_sel = select.and_selection(self.get_selection(),
                                       other.get_selection())
        return SelectAtoms(new_sel)

    def __or__(self, other):
        new_sel = select.or_selection(self.get_selection(),
                                      other.get_selection())
        return SelectAtoms(new_sel)

    def __invert__(self):
        new_sel = select.not_selection(self.get_selection())
        return SelectAtoms(new_sel)

    def __iter__(self):
        return SelectAtomsIterator(self)

    def __getitem__(self, key):
        return self.get_selection()[key]

    def is_selected(self, atom_index) -> bool:
        is_sel_i = False
        if atom_index < len(self.get_selection()):
            is_sel_i = self[atom_index]

        return is_sel_i

    def is_stored(self):
        return self._stored

    def get_stored_name(self):
        name = ''
        if self.is_stored():
            name = self._name

        return name

    def store(self, name=''):
        max_name = select.get_max_name()
        if name:
            self._name = name[:max_name]

        if not self._name:
            self._name = _generate_script_name()

        if len(self._name) > max_name:
            self._name = self._name[:max_name]

        select.store_selection(self._name, self.get_selection())
        self._stored = True
        return self._name

    def unstore(self):
        was_stored = self.is_stored()
        if was_stored:
            select.delete_stored_selection(self._name)
            self._stored = False

        return was_stored

    def __enter__(self):
        self.store()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.unstore()

    def _update(self):
        sel = self.get_selection()
        inds = [i for i, x in enumerate(sel) if x]
        self._atom_indexes = inds
        self._n_selected = len(inds)
        self._chem_types = atom_info.get_chem_types(inds)
        self._res_indexes = atom_info.get_res_indexes(inds)
        self._res_names = atom_info.get_res_names(inds)
        self._res_ids = atom_info.get_res_ids(inds)
        self._seg_indexes = atom_info.get_seg_indexes(inds)
        self._seg_ids = atom_info.get_seg_ids(inds)
        self._atom_types = atom_info.get_atom_types(inds)
        if self.is_stored():
            self.store()

        return self

    def get_atom_indexes(self):
        return self._atom_indexes[:]

    def get_n_selected(self):
        return self._n_selected

    def get_chem_types(self):
        return self._chem_types[:]

    def get_res_indexes(self):
        return self._res_indexes[:]

    def get_res_names(self):
        return self._res_names[:]

    def get_res_ids(self):
        return self._res_ids[:]

    def get_seg_indexes(self):
        return self._seg_indexes[:]

    def get_seg_ids(self):
        return self._seg_ids[:]

    def get_atom_types(self):
        return self._atom_types[:]


class SelectAtomsIterator:
    def __init__(self, select_atoms):
        self._select_atoms = select_atoms
        self._index = 0

    def __next__(self):
        if self._index < len(self._select_atoms):
            is_sel_i = self._select_atoms.is_selected(self._index)
            self._index += 1
            return is_sel_i

        raise StopIteration
