# pycharmm: molecular dynamics in python with CHARMM
# Copyright (C) 2018 Josh Buckner

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""get data from charmm associated with 'psf' files

Functions
---------
- `coor_pdb` -- write a coor pdb file to disk
- `psf_card` -- write a psf card file to disk
"""

import pycharmm.script


def coor_pdb(filename, title='', **kwargs):
    """write a coordinate set to a pdb file

    :param str filename: new file path to write
    :param str title: title to write at beginning of file
    :param dict kwargs: extra settings to pass to the charmm command
    """
    write_command = pycharmm.script.WriteScript(filename,
                                                title,
                                                coor='pdb',
                                                **kwargs)
    write_command.run()


def coor_card(filename, title='', **kwargs):
    """write a coordinate set to a charmm card *.chr format file

    :param str filename: new file path to write
    :param str title: title to write at beginning of file
    :param dict kwargs: extra settings to pass to the charmm command
    """
    write_command = pycharmm.script.WriteScript(filename,
                                                title,
                                                coor='card',
                                                **kwargs)
    write_command.run()


def psf_card(filename, title='', **kwargs):
    """write psf details in card format to a file

    :param str filename: new file path to write
    :param str title: title to write at beginning of file
    :param dict kwargs: extra settings to pass to the charmm command
    """
    write_command = pycharmm.script.WriteScript(filename,
                                                title,
                                                psf='card',
                                                **kwargs)
    write_command.run()


# def coor_pdb(filename, selection=None, comparison=False):
#     """write a coordinate set to a pdb file

#     Parameters
#     ----------
#     filename : string
#                new file path to write
#     selection : SelectAtoms
#                 a selection of atom indexes to write
#     comparison : bool
#                  if True, write from comparison set instead of main set

#     Returns
#     -------
#     status : bool
#              true if successful
#     """
#     if selection is None:
#         selection = pycharmm.SelectAtoms().all_atoms()

#     fn = ctypes.c_char_p(filename.encode())
#     len_fn = ctypes.c_int(len(filename))
#     c_comp = ctypes.c_int(comparison)

#     status = lib.charmm.write_coor_pdb(fn, ctypes.byref(len_fn),
#                                        selection.as_ctypes(),
#                                        ctypes.byref(c_comp))
#     status = bool(status)
#     return status


# def psf_card(filename):
#     """write psf details in card format to a file

#     Parameters
#     ----------
#     filename : string
#                new file path to write

#     Returns
#     -------
#     status : bool
#              true if successful
#     """
#     fn = ctypes.c_char_p(filename.encode())
#     len_fn = ctypes.c_int(len(filename))
#     status = lib.charmm.write_psf_card(fn, ctypes.byref(len_fn))
#     status = bool(status)
#     return status
