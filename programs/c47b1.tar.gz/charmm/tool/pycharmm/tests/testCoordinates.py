# This script tests the Coordinates class from the pycharmm pip package
# Written by Josh Buckner 24 November 2021

import pycharmm
import pycharmm.coor as coor
import pycharmm.generate as gen
import pycharmm.ic as ic
import pycharmm.read as read


read.rtf('toppar/top_all22_prot.inp')
read.prm('toppar/par_all22_prot.inp')

read.sequence_string('ALA GLY')
gen.new_segment(seg_name='ALAD',
                    first_patch='ACE',
                    last_patch='CT3',
                    setup_ic=True)

read.sequence_string('GLU')
gen.new_segment(seg_name='GLAD',
                    first_patch='ACE',
                    last_patch='CT3',
                    setup_ic=True)

read.sequence_string('SER')
gen.new_segment(seg_name='SAD',
                    first_patch='ACE',
                    last_patch='CT3',
                    setup_ic=True)

ic.prm_fill(False)
ic.seed(1, 'CAY', 1, 'CY', 1, 'N')
ic.build()

coor.orient(by_rms=False,by_mass=False,by_noro=False)

coor.show()

main_pos = pycharmm.Coordinates('main')
print('MAIN ==========')
print(main_pos.coords.to_markdown())
print('==========')

comp_pos = pycharmm.Coordinates('comp')
print('COMP ==========')
print(main_pos.coords.to_markdown())
print('==========')

comp2_pos = pycharmm.Coordinates('comp2')
print('COMP2 ==========')
print(main_pos.coords.to_markdown())
print('==========')
