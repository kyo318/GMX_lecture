#define TESTNAME "Initial coding. Intra frame BWLZH algorithm. High accuracy. Cubic cell."
#define FILENAME "test44.tng_compress"
#define ALGOTEST
#define NATOMS 100000
#define CHUNKY 1
#define SCALE 0.5
#define PRECISION 1e-8
#define WRITEVEL 0
#define VELPRECISION 0.1
#define INITIALCODING 9
#define INITIALCODINGPARAMETER 0
#define CODING 1
#define CODINGPARAMETER -1
#define VELCODING 4
#define VELCODINGPARAMETER 0
#define INTMIN1 0
#define INTMIN2 0
#define INTMIN3 0
#define INTMAX1 1610612736
#define INTMAX2 1610612736
#define INTMAX3 1610612736
#define NFRAMES 10
#define EXPECTED_FILESIZE 1436901.
